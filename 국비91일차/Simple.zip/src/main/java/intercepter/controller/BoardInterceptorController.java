package intercepter.controller;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class BoardInterceptorController {

	private static final Logger logger = LoggerFactory.getLogger(InterceptorLoginController.class);
	
	@RequestMapping(value="/interceptor/board/list")
	public void boardList(HttpSession session) {
		logger.info("/interceptor/board/list");
	}

	@RequestMapping(value="/interceptor/board/write")
	public void boardWrite(HttpSession session) {
		logger.info("/interceptor/board/write");	
	}
	
	@RequestMapping(value="/interceptor/board/noLogin")
	public void boardNoLogin(HttpSession session) {
		logger.info("/interceptor/board/noLogin");
		session.invalidate();
	}
}
