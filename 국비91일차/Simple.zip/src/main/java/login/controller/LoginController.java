package login.controller;

import java.nio.channels.SeekableByteChannel;
import java.util.HashMap;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import login.dto.Login;
import login.service.LoginService;
import web.controller.ParamController;
import web.dto.User;

@Controller
public class LoginController {

	//로깅객체
	private static final Logger logger = LoggerFactory.getLogger(ParamController.class);

	//서비스 객체
	@Autowired
	private LoginService loginService;
	
	// 홈 화면 컨트롤러
	@RequestMapping(value="/login/main")
	public void main(HttpSession session, Model model) {
		Login login = new Login();	
		if(session != null) { // 세션이 있는지 확인 하는 코드
			login =(Login)session.getAttribute("user") ;
		}
		//로그인 정보가 있으면 모델로 객체를 넘긴다.
		model.addAttribute("user", login);	
	
		//--------------선생님코드------------------
			
	}
	
	// 로그인 화면 컨트롤러
	@RequestMapping(value="/login/login")
	public void login() {
		logger.info("login/login get");
	}
	
	// 로그인 화면 컨트롤러
	@RequestMapping(value="/login/login", method = RequestMethod.POST)
	public String loginResult(@RequestParam HashMap<String, String> map, HttpSession session) {
		logger.info("/login/login post");		
		logger.info(map.toString());
		
		Login login = null;
		
		// 로그인 정보 찾아옴
		login = loginService.findUser(map);
		
		// 로그인한 아이디가 null이거나 빈문자일때 다시 로그인 페이지로 보냄
		if(login.getId() == null || login.getId() == "") {
			return "redirect:/login/login";
		}
		
		// 로그인한 정보가 있으며, 로그인 여부 true 와 해당 유저 정보 세션저장
		session.setAttribute("login", true);
		session.setAttribute("user", login); // 사실 세션에 비밀번호를 넣으면 안된다.
				
		return "login/main";
		
		//--------------선생님코드------------------
		// public String loginResult(Login login, HttpSession session)
		// logger.info("/login/login [post]");
		// 아이디, 패스워드 DB 조회 -  인증
		// boolean isLogin = loginService.login(login); // true 인증 성공
		// if(isLogin){
		// session.setAttribute("login", isLogin);
		// session.setAttribute("loginid", login.getId());
		//	
		//
		//  }
		// return "redirect:/login/main";}
	}

	// -- 로그아웃 메소드
	@RequestMapping(value = "login/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		
		return "redirect:/login/main";
	}
		
	// -- 마이페이지 화면 컨트롤러
	@RequestMapping(value="/login/mypage")
	public String  mypage(HttpSession session, Model model) {	
		//로그인 했는지 여부 체크 -> 안했으면 메인으로 보내보림
		if(session == null) {
			return "redirect:/login/main";
		}		
		Login login = (Login) session.getAttribute("user");		
		
		model.addAttribute("user", login);
		return "login/mypage";	
		
		//--------------선생님코드------------------
		// String loginid = (String) session.getAttreibute("loginid"); // 세션에는 기본키만 저장한다
		// 비밀번호는 절대 세션에 저장하면 안된다!!!!!!!!!!!
		// Login info = loginService.info(loginid); // 로그인된 사용자 정보 조회
		// logger.info("/login/mypage info: {}", info)
		// model.addAttribute("info", info);
		 
	}
	
	// -- 조인 화면 컨트롤러
	@RequestMapping(value="/login/join")
	public void  join() {}

	// -- 조인 화면 컨트롤러 [가입 데이터 받는 쿼리]
	@RequestMapping(value="/login/join", method = RequestMethod.POST)
	public String joinResult(@RequestParam HashMap<String, String> map) {
		loginService.joinUser(map);
		return "redirect:/login/main";

		//--------------선생님코드------------------
		// public String joinResult(Login login) {
		// logger.info("login/join [POST]");
		// logger.info("전달파라미터 {}", login);
		// loginService.joinUser(login); // 회원가입처리
		// return "redirect:/login/main";
	}
	
}
