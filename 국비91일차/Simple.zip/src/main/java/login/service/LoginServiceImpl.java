package login.service;

import java.util.HashMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import login.dao.LoginDao;
import login.dto.Login;

@Service
public class LoginServiceImpl implements LoginService{

	//DAO 객체
	@Autowired
	private LoginDao loginDao;

	/*
	 * @Autowired private SqlSession sqlSession;
	 */

	@Override // 유저 회원가입 하는 메소드
	public void joinUser(HashMap<String, String> map) {
		loginDao.InsertUser(map);	
	}


	@Override // 유저 정보를 찾아오는 메소드
	public Login findUser(HashMap<String, String> map) {
		Login login = null; 
		login = loginDao.selectUser(map);

		// 해당 아이디 값이 없거나 정보가 같지 않으면,
		if(login == null) {
			login = new Login();
		}	
		return login;
	}

	/**
	 * 로그인 인증 처리
	 * id /pw 를 이용하여 행 count를 조회한다
	 * 존재하면 인증 성공 true 반환
	 * 존재하지 않으면 인증 실패 false 반환
	 * 
	 * @param login
	 * @return
	 * 	
	 * 	true - 로그인 인증 성공
	 *  false - 로그인 인증 실패
	 */
//	public boolean login2(Login login) {
//		if(loginDao.selectCnt(login) >= 1) {
//			return true;
//		}
//		return false;
//	}

}
