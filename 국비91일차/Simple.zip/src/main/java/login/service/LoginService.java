package login.service;

import java.util.HashMap;

import login.dto.Login;

public interface LoginService {

	/**
	 * 신규 회원 가입을 하는 메소드
	 * 
	 * @param map
	 */
	public void joinUser(HashMap<String, String> map);

	/**
	 * 유저 정보를 가져오는 메소드
	 * 
	 * @param map
	 * @return
	 */
	public Login findUser(HashMap<String, String> map);

}
