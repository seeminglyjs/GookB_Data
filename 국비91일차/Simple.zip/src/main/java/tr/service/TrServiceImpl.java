package tr.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import tr.dao.TrDao;

@Service
public class TrServiceImpl implements TrService{

	
	@Autowired 
	TrDao trDao;
	
	@Override
	@Transactional
	public void test(int deptno) {
	
		trDao.insert1(deptno);
		trDao.insert2(deptno);
	
	}
}
