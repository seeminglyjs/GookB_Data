package di.xml;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import di.tire.Tire;

public class Person {

	public static void main(String[] args) {
		
		//스프링 어플리케이션 컨텍스트 객체
		ApplicationContext context = null;
		
		context = new FileSystemXmlApplicationContext("/src/main/java/di/xml/di.xml");
	
		
		//Spring 컨텍스트에 등록된 "car" 라는 이름의 빈(객체)로 의존성 주입
		Car car = (Car)context.getBean("car");
	
		//Spring 컨텍스트에 등록된 "gTire"라는 이름의 빈으로 객체 의존성 주입
		car.setTire((Tire) context.getBean("gTire"));
	
	
		System.out.println(car.getInfo());
	
		//-------------------------------------------------
		
		System.out.println("---------------------------");
		Car c1 = (Car)context.getBean("car");
		c1.setTire((Tire) context.getBean("sTire"));
		
		System.out.println("c1 - > " + c1);
		System.out.println("c1 info - > " + c1.getInfo());
		
		System.out.println("---------------------------");
		
		Car c2 = (Car)context.getBean("car");
		c2.setTire((Tire) context.getBean("gTire"));
		
		System.out.println("c2 - > " + c2);
		System.out.println("c2 info - > " + c2.getInfo());
	}
}
