package di.tire;

public class SilverTire implements Tire{

	@Override
	public String getProduct() {
	
		return "실버타이어";
	}
}
