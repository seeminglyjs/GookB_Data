package web.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class PageController {
	//로깅객체
	private static final Logger logger = LoggerFactory.getLogger(ParamController.class);

	@RequestMapping(value="page/redirect")
	public String redirectPage() {
		logger.info("page/redirect get 요청");
		
		return "redirect:/param/requestParam";
	}


	@RequestMapping(value="/page/redirect2")
	public ModelAndView redirectPageMav(ModelAndView mav) {
		logger.info("page/redirect2 get 요청");
		mav.setViewName("redirect:/param/test");
		
		return mav;
		
	}
	
	@RequestMapping(value = "/page/forward")
	public String forwardPage() {
		logger.info("포워드 테스트");
		return"forward";
	}
	
}
