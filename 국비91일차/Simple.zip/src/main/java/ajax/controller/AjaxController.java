package ajax.controller;

import java.io.IOException;
import java.io.Writer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import ajax.dto.ResultData;

@Controller
public class AjaxController {

	private static final Logger logger = LoggerFactory.getLogger(AjaxController.class);

	
	//------------------------------------------------
	// 1. 응답 출력 스트림을 이용하여 JSON Text를 직접 출력하기
	@RequestMapping(value = "/ajax/test01")
	public void ajaxTest01() {
		logger.info("ajax test01 [--get]");
	}

	
	@RequestMapping(value = "/ajax/test01_ok")
	public void ajaxTest01_ok(Writer out) { 
		// viewResolver로 보내지 않도록 응답출력스트림을 사용한다
		logger.info("ajax test01 ok [--get]");
	
		try {
			out.write("{\"result\" : true}");
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	
	//------------------------------------------------
	// 2. @ResponseBody 를 이용하여 객체를 JSON Text로 응답하기
	// jackson_databind 라이브러리 필요
	
	// ** jackson : java 객체 <-> json 변환을 도와주는 자바 라이브러리
	
	@RequestMapping(value = "/ajax/test02")
	public void ajaxTest02() {
		logger.info("ajax test02 [--get]");
	}

	
	/* ------ hashmap을 이용해서 ajax 응답값 전달 처리 방법 알아보기
	 * 
	 * 
	 * @RequestMapping(value = "/ajax/test02_ok") 
	 * public @ResponseBody HashMap<String, Object> ajaxTest02_ok() {
	 * logger.info("ajax test02 ok [--get]");
	 * 
	 * // json은 키가 String value는 Obejct 타입이다. HashMap<String, Object> map = new
	 * HashMap<>(); map.put("A", "Apple"); map.put("B", 123); map.put("result",
	 * false);
	 * 
	 * return map;
	 * 
	 * }
	 */

	
	
	//------ DTO 을 이용해서 ajax 응답값 전달 처리 방법 알아보기

//	@RequestMapping(value = "/ajax/test02_ok")
//	public @ResponseBody ResultData ajaxTest02_ok() { 
//		logger.info("ajax test02 ok [--get]");
//
//		ResultData rd = new ResultData("apple", 12345, true);
//		
//		return rd;
//	
//	}


	//------ List 를 이용해서 ajax 응답값 전달 처리 방법 알아보기

//	@RequestMapping(value = "/ajax/test02_ok")
//	public @ResponseBody List<ResultData> ajaxTest02_ok() { 
//		logger.info("ajax test02 ok [--get]");
//
//		List<ResultData> list = new ArrayList<>();
//		
//		list.add(new ResultData("abc1", 1111, true));
//		list.add(new ResultData("abc2", 2211, false));
//		list.add(new ResultData("abc3", 3311, true));
//		
//		return list;
//	
//	}
	
	
	//------------------------------------------------
	// 3. AJAX의 응답으로 JSP응답을 활용하기
	// 전달해야 하는 데이터(모델값)을 JSP에 전달하고 JSP로 포워딩
	// 완성된 HTML코드로 응답데이터를 전송한다
	@RequestMapping(value = "/ajax/test03")
	public void ajaxTest03() {
		logger.info("ajax test03 [--get]");
	}
	
	@RequestMapping(value="/ajax/test03_ok")
	public String ajaxTest03_ok(Model model) {
		
		model.addAttribute("rd1", new ResultData("a", 123, true));
		model.addAttribute("rd2", new ResultData("b", 321, false));
		
		return "ajax/test03_ok_response";
	}

	
	//------------------------------------------------
	// 4. JSON을 생성하는 전용 View 사용 - jsonView
	// jsonView를 Spring Bean으로 등록한다
	// BeanNameViewResovler를 이용하여 jsonView로 응답한다
	@RequestMapping(value = "/ajax/test04")
	public void ajaxTest04() {
		logger.info("ajax test04 [--get]");
	}
	
	@RequestMapping(value="/ajax/test04_ok")
	public ModelAndView ajaxTest04_ok(ModelAndView mav) {
	
		mav.setViewName("jsonView");
		
		mav.addObject("rd1", new ResultData("aaa", 123, true));
		
		return mav;
	}
	
	
}
