package ajax.dto;

public class ResultData {

	private String data1;
	private int data2;
	private boolean result;

	public ResultData() {
	}
	
	public ResultData(String data1, int data2, boolean result) {
		this.data1 = data1;
		this.data2 = data2;
		this.result = result;
	}
	
	
	@Override
	public String toString() {
		return "ResultData [data1=" + data1 + ", data2=" + data2 + ", result=" + result + "]";
	}
	
	
	public String getData1() {
		return data1;
	}
	public void setData1(String data1) {
		this.data1 = data1;
	}
	public int getData2() {
		return data2;
	}
	public void setData2(int data2) {
		this.data2 = data2;
	}
	public boolean isResult() {
		return result;
	}
	public void setResult(boolean result) {
		this.result = result;
	}
	
	
}
