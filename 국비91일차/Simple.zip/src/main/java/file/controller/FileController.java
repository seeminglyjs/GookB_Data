package file.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import file.dto.FileTest;
import file.service.face.FileService;

@Controller
public class FileController {

	private static final Logger logger = LoggerFactory.getLogger(FileController.class);
	
	@Autowired
	FileService fileService;
	
	@RequestMapping(value = "/file/fileup", method=RequestMethod.GET)
	public void fileForm() {
		logger.info("/file/fileup [--get-]");
	}
	
	@RequestMapping(value = "/file/fileup", method=RequestMethod.POST)
	public void fileup(String title
			, @RequestParam(value="title") String t
			, MultipartFile file
			, @RequestParam(value="file", required=false) MultipartFile fileupload){
		
		logger.info("/file/fileup [--post-]");
		logger.info("title : {}", title);
		logger.info("title : {}", t);
		logger.info("file : {}", file);
		logger.info("file : {}", fileupload);
	
		// 파일의 원본 이름 가져오기
		logger.info("fileupload : {}", fileupload.getOriginalFilename());
	
	
		//업로드된 파일을 저장하고 기록 저장하기
		fileService.filesave(title,fileupload);
		
	}
	
	// 전체 파일 목록을 출력할 컨트롤러
	@RequestMapping(value ="/file/list")
	public void filelist(Model model) {
		List<FileTest>list = fileService.list();
		model.addAttribute("list", list);
	}
	
	// 파일을 다운로드 하는 컨트롤러
	@RequestMapping(value ="/file/download")
	public String download(int fileno, Model model) {
		logger.info("/file/download fileno : {} ", fileno);
		
		//파일번호에 해당하는 파일정보를 가져오기(DB 이용)
		FileTest file = fileService.getFile(fileno);
		logger.info("조회된 파일{}", file);
		
		//다운로드할 파일의 정보를 모델값으로 뷰에 전달
		model.addAttribute("downFile", file);
		
		
		return "down";
	}
	
}
