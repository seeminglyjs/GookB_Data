package file.dao.face;

import java.util.List;

import file.dto.FileTest;

public interface FileDao {

	/**
	 * 전달된 파일 정보를 삽입
	 * 
	 * 
	 * @param filetest 업로드된 파일의 정보 dto 객체
	 */
	public void insertFile(FileTest filetest);

	/**
	 * 업로드된 전체 파일목록을 리턴하는 메소드
	 * 
	 * @return
	 */
	public List<FileTest> selectAll();

	/**
	 * fileno를 이용한 조회
	 * 
	 * @param fileno 조회할 파일정보
	 * @return
	 */
	public FileTest selectByFileno(int fileno);

}
