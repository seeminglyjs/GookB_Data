package file.service.face;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import file.dto.FileTest;

public interface FileService {

	/**
	 * 업로드된 파일을 처리한다
	 * 
	 * @param title 제목
	 * @param fileupload 업로드된 파일정보 객체
	 */
	public void filesave(String title, MultipartFile fileupload);

	/**
	 * 업로드된 파일 목록을 조회한다 
	 * 
	 * @return
	 */
	public List<FileTest> list();

	/**
	 * 파일번호를 이용해서 업로드된 파일 정보를 가져온다.
	 * 
	 * @param fileno 지정된 파일의 번호
	 * @return 조회된 파일 정보 객체
	 */
	public FileTest getFile(int fileno);

}
