package dao.impl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import common.JDBCTemplate;
import dao.face.FileDao;
import dto.ParamData;
import dto.UploadFile;

public class FileDaoImpl implements FileDao {

	private PreparedStatement ps = null;
	private ResultSet rs = null;
	
	@Override
	public int insertParam(Connection conn, ParamData paramData) {
		
		String sql = "";
		sql += "INSERT INTO paramdata( datano, title, data1, data2 )";
		sql += " VALUES( paramdata_seq.nextval, ?, ?, ? )";
		
		int result = 0;
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, paramData.getTitle());
			ps.setString(2, paramData.getData1());
			ps.setString(3, paramData.getData2());
			
			result = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(ps);
		}
		
		return result;
	}

	@Override
	public int insertFile(Connection conn, UploadFile uploadFile) {
		
		String sql = "";
		sql += "INSERT INTO uploadfile( fileno, origin_name, stored_name )";
		sql += " VALUES( uploadfile_seq.nextval, ?, ? )";
		
		int result = 0;
		
		try {
			ps = conn.prepareStatement(sql);
			ps.setString(1, uploadFile.getOriginName());
			ps.setString(2, uploadFile.getStoredName());
			
			result = ps.executeUpdate();
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(ps);
		}		
		
		return result;
	}

	@Override
	public List<UploadFile> selectAll(Connection conn) {
		
		String sql = "";
		sql += "SELECT * FROM uploadfile";
		sql += " ORDER BY fileno DESC";
		
		List<UploadFile> list = new ArrayList<>();
		
		try {
			ps = conn.prepareStatement(sql);
			
			rs = ps.executeQuery();
			
			while( rs.next() ) {
				UploadFile file = new UploadFile();
				
				file.setFileno( rs.getInt("fileno") );
				file.setOriginName( rs.getString("origin_name") );
				file.setStoredName( rs.getString("stored_name") );
				
				list.add( file );
			}
			
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			JDBCTemplate.close(rs);
			JDBCTemplate.close(ps);
		}
		
		return list;
	}

}














