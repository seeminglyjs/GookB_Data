package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import service.face.FileService;
import service.impl.FileServiceImpl;

@WebServlet("/commons/fileupload")
public class CommonsFileuploadController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	//서비스 객체
	private FileService fileService = new FileServiceImpl();
		
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		//View지정하고 포워드(forward)
		//	-> 파일업로드 <form>페이지 띄우기
		req.getRequestDispatcher("/WEB-INF/views/commons/fileupload.jsp")
			.forward(req, resp);
		
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("/commons/fileupload [POST] - 접속 완료");
		
		//파일 업로드 처리 - 서비스 객체 이용
		fileService.fileupload(req, resp);
		
		//파일 목록 페이지로 이동 - 리다이렉트
		resp.sendRedirect("/file/list");
		
		
		
		
		
		
		//----------------------------------------------------------
		
		//전달파라미터 확인
//		System.out.println("title : " + req.getParameter("title"));
//		System.out.println("data1 : " + req.getParameter("data1"));
//		System.out.println("data2 : " + req.getParameter("data2"));
//		System.out.println("upfile : " + req.getParameter("upfile"));
		
		// ** 파일은 파일의 이름만 전송된 상태
		// ** 파일의 내용물(컨텐츠)는 전송되지 않았다
		
		//----------------------------------------------------------
		
		//	 <form>태그의 전달파라미터를 전송하는 방식(enctype)을
		//	기본값인 application/x-www-form-urlencoded방식으로 설정하면
		//	type="file"인 데이터에 파일이름만 전송된다
		//		-> 파일의 내용물이 전달되지 않는다
		
		//		-> 전달파라미터는 req.getParameter()메소드를 이용한다	
		
		//----------------------------------------------------------
		
		//	 enctype을 multipart/form-data방식으로 설정하면
		//	type="file"인 데이터에 파일의 내용물을 전송한다
		
		//		-> 전달파라미터는 req.getParameter()메소드를
		//		 이용할 수 없다
		//		-> req.getParameter()의 반환값이 null 이다
		
		//		-> 파일업로드 라이브러리를 활용해서 처리해야만 한다
		
		//		-> Commons-Fileupload 라이브러리
		//		-> COS 라이브러리
		
		
	}
	
}










