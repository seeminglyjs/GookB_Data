package controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;

import com.oreilly.servlet.MultipartRequest;
import com.oreilly.servlet.multipart.DefaultFileRenamePolicy;
import com.oreilly.servlet.multipart.FileRenamePolicy;

import dto.UploadFile;
import service.face.FileService;
import service.impl.FileServiceImpl;

@WebServlet("/cos/fileupload")
public class CosFileuploadController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	//서비스 객체
	private FileService fileService = new FileServiceImpl();
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("/cos/fileupload [GET] - 요청 완료");
	
		req.getRequestDispatcher("/WEB-INF/views/cos/fileupload.jsp")
			.forward(req, resp);
		
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("/cos/fileupload [POST] - 요청 완료");
		
		//--- multipart/form-data 검증 ---
		if( !ServletFileUpload.isMultipartContent(req) ) {
			//파일 업로드 형식의 요청이 아닐 경우 처리
			
			
			//에러페이지에 전달할 메시지 작성하기 - MODEL값
			req.setAttribute("message", "form태그의 enctype속성이 안맞습니다");
			
			
			req.setAttribute("alertMsg", "경고! 알림창!");
			req.setAttribute("redirectURL", "/file/list");
			
			
			//에러처리 전용 View로 응답하기 - forwarding
			req.getRequestDispatcher("/WEB-INF/views/file/error.jsp")
				.forward(req, resp);
			
			
			return; //doPost() 메소드를 중단시킨다
		}
		//--------------------------------
		
		//--- 매개변수 준비 ---
		//1. 요청 객체
		//	-> req
		
		//2. 파일 저장 위치
		String saveDirectory = getServletContext().getRealPath("upload");
		
		//3. 업로드 제한 크기
		int maxPostSize = 10 * 1024 * 1024; //10MB
		
		//4. 한글 인코딩
		String encoding = "UTF-8";
		
		//5. 중복될 파일이름을 처리할 방법
		FileRenamePolicy policy = new DefaultFileRenamePolicy();
		//---------------------
		
		//** DefaultFileRenamePolicy 클래스
		//	 이미 업로드된 파일 중에서 같은 이름이 있다면
		//	새롭게 업로드된 파일이름에 번호를 붙여서 구분한다
		//	 -> 자동으로 1부터 1씩 증가하면서 부여된다
		
		//---------------------
		
		
		
		//--- COS파일 업로드 객체 생성 ---
		MultipartRequest mul = new MultipartRequest(
				req
				, saveDirectory
				, maxPostSize
				, encoding
				, policy );
		
		//MultipartRequets 객체가 생성되면서 파일 업로드가 수행된다
		//--------------------------------
		
		
		
		//원본 파일 이름
		String origin = mul.getOriginalFileName("upfile");
		
		//저장된 파일 이름
		String stored = mul.getFilesystemName("upfile");
		
		System.out.println("/cos/fileupload [POST] - origin : " + origin);
		System.out.println("/cos/fileupload [POST] - stored : " + stored);
		
		//DB정보 저장할 DTO 객체
		UploadFile up = new UploadFile();
		up.setOriginName(origin);
		up.setStoredName(stored);
		
		//DB에 업로드 파일 정보 기록하기
		fileService.filesave(up);
		
		
		
		//전달파라미터 확인
		System.out.println( mul.getParameter("title") );
		System.out.println( mul.getParameter("nick") );
		
		
		
		//목록 페이지로 리다이렉트
		resp.sendRedirect("/file/list");
	}
	
}
















