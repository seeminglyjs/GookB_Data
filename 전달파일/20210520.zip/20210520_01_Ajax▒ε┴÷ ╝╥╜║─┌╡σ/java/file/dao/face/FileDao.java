package file.dao.face;

import java.util.List;

import file.dto.Filetest;

public interface FileDao {

	/**
	 * 전달된 파일 정보를 삽입
	 * 
	 * @param filetest 업로드된 파일의 정보 DTO 객체
	 */
	public void insertFile(Filetest filetest);

	/**
	 * 업로드된 전체 파일을 조회한다
	 * 
	 * @return 업로드된 파일들의 목록
	 */
	public List<Filetest> selectAll();
	
	/**
	 * fileno를 이용한 조회
	 * 
	 * @param fileno 조회할 파일번호
	 * @return 조회된 파일 정보 객체
	 */
	public Filetest selectByFileno(int fileno);
	
}












