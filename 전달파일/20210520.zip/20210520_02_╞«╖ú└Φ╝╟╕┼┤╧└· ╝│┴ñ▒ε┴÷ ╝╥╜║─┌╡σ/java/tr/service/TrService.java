package tr.service;

public interface TrService {

	public void test(int deptno);
	
}
