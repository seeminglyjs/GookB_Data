package tr.dao;

public interface TrDao {

	public void insert1(int deptno);
	
	public void insert2(int deptno);
	
}
