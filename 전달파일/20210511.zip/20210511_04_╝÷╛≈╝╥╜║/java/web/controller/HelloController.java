package web.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class HelloController {
	
	private static final Logger logger
	= LoggerFactory.getLogger(HelloController.class);

	@RequestMapping(value = "/hi", method = RequestMethod.GET)
	public void hi() {
		
		System.out.println("/hi [GET]");                                       
		
	}
	
	
	@RequestMapping(value = "/hello", method = RequestMethod.GET)
	public String hello() {
		
		logger.info("/hello [GET]");
		
		logger.debug("변수 출력하기 : {}", 1000);
		
		return null;
	}
	
}










