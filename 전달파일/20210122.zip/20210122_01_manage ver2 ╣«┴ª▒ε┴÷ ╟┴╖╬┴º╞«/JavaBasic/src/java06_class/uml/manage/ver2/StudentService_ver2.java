package java06_class.uml.manage.ver2;

public class StudentService_ver2 {

}
