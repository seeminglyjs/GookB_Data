import java.util.UUID;

public class UUIDEx {
	public static void main(String[] args) {
		
		//UUID, Universally Unique IDenfier
		
		String uuid = UUID.randomUUID().toString();
		System.out.println(uuid);
		
		String[] uids = uuid.split("-");
		System.out.println( uids[4] );
		
		System.out.println("--------------------");
		
		System.out.println( UUID.randomUUID().toString().split("-")[4] );
	}
}


