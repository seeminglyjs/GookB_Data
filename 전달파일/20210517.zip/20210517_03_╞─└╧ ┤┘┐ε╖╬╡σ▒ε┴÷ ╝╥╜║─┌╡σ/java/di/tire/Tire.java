package di.tire;

public interface Tire {
	public String getProduct();
}
