package web.controller;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import web.dto.User;

@Controller
public class ParamController {

	//로깅 객체
	private static final Logger logger = LoggerFactory.getLogger(ParamController.class);

	
	@RequestMapping(value="/param/requestParam", method=RequestMethod.GET)
	public String paramForm() {
		logger.info("/param/requestParam [GET] 요청 성공");
		
		//VIEW 지정
		return "param/paramForm";
	}
	
	@RequestMapping(value="/param/requestParam", method=RequestMethod.POST)
	public String paramResult(
			
			@RequestParam(value = "aaaaa", required = true) String name
			, @RequestParam(value = "bbbbb", required = false) int age
			
			
			, HttpServletRequest req
//			, Reader reader
//			, InputStream in
			
			, HttpServletResponse resp
//			, Writer out
//			, OutputStream os
			
			, HttpSession session
			
			, Model model
			, ModelAndView mav
			, ModelMap modelMap
			
			) {
		
		logger.info("/param/requestParam [POST] 요청 성공");
		
		logger.info(name);
		logger.info("{}", age);
		logger.info("" + age);
		
		//----------------------------------------------------------
		
		model.addAttribute("name", name);
		model.addAttribute("age", age);
		
		return "param/paramResult";
	}
	
	@RequestMapping(value="/param/required")
	public void requiredTest( @RequestParam(required=true) String test ) {
		
		logger.info("/param/required : {}", test);
		
	}
	
	@RequestMapping(value="/param/mapForm", method=RequestMethod.GET)
	public void paramMapForm() {
		logger.info("/param/mapForm [GET]");
	}
	
	@RequestMapping(value="/param/mapResult", method=RequestMethod.POST)
	public void paramMapResult(
			@RequestParam HashMap<String, String> map
			, Model model
			) {
		
		logger.info("/param/mapResult [POST]");
		logger.info(map.toString());
		
		// 맵객체 자체를 모델값으로 전달한다
		model.addAttribute("m", map);
		
		// 맵객체 내부의 키=값 쌍을 각각의 모델값으로 분리해서 전달한다
		model.addAllAttributes(map);
		
	}
	
	@RequestMapping(value="/param/dto", method=RequestMethod.GET)
	public void paramDtoForm() {
		logger.info("/param/dto [GET]");
		
	}
	
	@RequestMapping(value="/param/dto", method=RequestMethod.POST)
	public String paramDto(
			
			User user //커맨드 객체
			, @ModelAttribute("userData") User user2 //커맨드 객체
			
			, Model model
			
			) {
		
		logger.info("/param/dto [POST]");
		
		logger.info("user : {}", user);
		logger.info("user2 : {}", user2);
		
		//------------------------------------------
		
		user2 = new User();
		
		user2.setName("Banana");
		user2.setAge(55555);
		
		model.addAttribute("userData", user2);
		
		return "param/dtoResult";
	}
	
	
	
	//----------------------------------------------------------------
	
	
	@RequestMapping(value="/param/test")
	public void paramTest1( Model model ) {
		
		//viewName : param/test
		//view : /WEB-INF/views/param/test.jsp
		
		model.addAttribute("data", "MODEL DATA");
		
	}
	
	@RequestMapping(value="/param/test2")
	public String paramTest2( Model model ) {
		
		model.addAttribute("data", "MODEL DATA 2");
		
//		return null; //void리턴타입과 같은 동작
		
		return "param/test";
		
	}
	
	@RequestMapping(value="/param/test3")
	public ModelAndView paramTest3( ModelAndView mav ) {
		
//		ModelAndView mav = new ModelAndView();
		
		mav.addObject("data", "MODEL DATA 3"); //모델값 지정
		
		mav.setViewName("param/test"); //viewName 지정
//		mav.setViewName(null); //void 리턴타입과 동일한 동작
		
		return mav;
	}
	
}
















