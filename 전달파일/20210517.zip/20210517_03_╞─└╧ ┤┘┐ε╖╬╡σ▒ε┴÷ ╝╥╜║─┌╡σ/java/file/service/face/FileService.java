package file.service.face;

import java.util.List;

import org.springframework.web.multipart.MultipartFile;

import file.dto.Filetest;

public interface FileService {

	/**
	 * 업로드된 파일을 처리한다
	 * 
	 * @param title 제목
	 * @param fileupload 업로드된 파일정보 객체
	 */
	public void filesave(String title, MultipartFile fileupload);
	
	/**
	 * 업로드된 파일 목록을 조회한다
	 * 
	 * @return 업로드된 파일의 목록
	 */
	public List<Filetest> list();

	/**
	 * 파일번호를 이용하여 업로드된 파일의 정보를 조회한다
	 * 
	 * @param fileno 지정된 파일의 번호, 다운로드시켜줄 파일 번호
	 * @return 조회된 파일 정보 객체
	 */
	public Filetest getFile(int fileno);
	
}















