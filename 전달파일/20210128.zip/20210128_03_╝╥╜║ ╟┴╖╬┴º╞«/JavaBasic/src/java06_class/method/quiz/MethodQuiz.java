package java06_class.method.quiz;

public class MethodQuiz {

	//Q1.
	public void print100() {
		
		//1~100���
		for(int i=1; i<=100; i++) { //i, 1~100, x100
			System.out.println(i);
		}
		
	}
	
	//Q2.
	public void printHello(int n) {
		for(int i=0; i<n; i++) { //i, 0 ~ n-1, n�� 
			System.out.println("Hello");
		}
	}
	
	//Q3.
	public void printText(int cnt, String text) {
		for(int i=0; i<cnt; i++) { //i, 0 ~ cnt-1, cnt��
			
			System.out.println(text);
			
		}
	}
	
}









