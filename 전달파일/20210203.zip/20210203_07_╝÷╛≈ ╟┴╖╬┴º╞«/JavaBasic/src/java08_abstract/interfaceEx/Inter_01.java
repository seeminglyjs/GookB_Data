package java08_abstract.interfaceEx;

public interface Inter_01 {
	public abstract void out();
}
