package web.controller;


import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import web.dto.Dept;
import web.service.HelloService;

@Controller
public class HelloController {
	
	//로깅 객체
	private static final Logger logger
	= LoggerFactory.getLogger(HelloController.class);

	//서비스 객체
	@Autowired private HelloService helloService;
	
	@RequestMapping(value = "/hi", method = RequestMethod.GET)
	public void hi() {
		
		System.out.println("/hi [GET]");                                       
		
	}
	
	
	@RequestMapping(value = "/hello", method = RequestMethod.GET)
	public String hello( String keyword, Model model ) {
		
		logger.info("/hello [GET]");
		
		logger.debug("변수 출력하기 : {}", 1000);
		logger.info("전달파라미터 param : {}", keyword);

		//--------------------------------------------------------------
		
		List<Dept> list = helloService.serviceTest();
		
		//View에 전달값 전달하기 - 모델값
		model.addAttribute("list", list);
		
		//viewName 지정하기
		return "test/hello";
		
	}
	
}










