package web.dao;

import java.util.List;

import web.dto.Dept;

public interface HelloDao {

	public List<Dept> selectAll(); 
	
}




