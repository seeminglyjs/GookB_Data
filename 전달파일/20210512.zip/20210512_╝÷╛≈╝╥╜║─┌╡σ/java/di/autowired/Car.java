package di.autowired;

import javax.inject.Inject;

import di.tire.Tire;

public class Car {
	
//	@Autowired
//	@Resource
	@Inject
//	@Qualifier("gTire") //의존성 주입될 스프링빈 이름 지정
	private Tire tire;
	
	public String getInfo() {
		return tire.getProduct() + " 장착함!!!";
	}
	
	public void setTire(Tire tire) {
		this.tire = tire;
	}

	public Tire getTire() {
		return tire;
	}
	
}
