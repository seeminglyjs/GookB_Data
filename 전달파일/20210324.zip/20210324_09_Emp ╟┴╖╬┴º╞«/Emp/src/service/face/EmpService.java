package service.face;

import java.util.List;

import dto.Emp;

public interface EmpService {

	/**
	 * 사원 전체 조회
	 * 
	 * @return 조회된 전체 사원들의 목록을 List로 반환한다
	 */
	public List<Emp> list();

}











