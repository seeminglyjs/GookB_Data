package hello;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//일반 클래스를 서블릿클래스로 만들어서 사용
public class HiServlet extends HttpServlet {

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		//콘솔창 출력
		System.out.println("doGet");
		
		
		
		//--- 응답메시지 만들기 ---
		//	-> HTML코드로 클라이언트에게 응답하기
		
		//응답메시지 형식을 지정하기 (UTF-8한글인코딩을 사용하는 HTML코드)
		resp.setContentType("text/html; charset=utf-8");
		
		//서블릿클래스 -> 브라우저 출력 스트림 생성		
		PrintWriter out = resp.getWriter();
		
		//브라우저로 HTML코드 출력하기(HTTP 응답하기)
		out.println("<h1>우리가 직접 만든 서블릿클래스!</h1>");
		out.println("<h3>안녕!</h3>");
		
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		//콘솔창 출력
		System.out.println("doPost");
		
	}
	
}














