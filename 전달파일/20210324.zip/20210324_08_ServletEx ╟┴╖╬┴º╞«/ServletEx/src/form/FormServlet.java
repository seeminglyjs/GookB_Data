package form;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/form.do")
public class FormServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("FormServlet - /form.do : GET요청");
		
		//JSP로 응답데이터 만들기 - VIEW 지정하기
		RequestDispatcher rd;
		rd = req.getRequestDispatcher("/WEB-INF/views/inputForm.jsp");
		
		//JSP로 응답 보내기
		rd.forward(req, resp);
		
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("FormServlet - /form.do : POST요청");

		//------------------------------------------------------

		//요청 데이터의 한글 인코딩 설정 : UTF-8
		req.setCharacterEncoding("UTF-8");
		
		//응답 데이터의 형식 지정 : HTML문서(한글인코딩UTF-8)
		resp.setContentType("text/html; charset=utf-8");
		
		//------------------------------------------------------
		
		//HttpServletRequest 객체의 메소드
		
		//	String getParameter(String name)
		//		-> 요청파라미터로 전달된 데이터를 얻어온다
		//		-> 매개변수로 파라미터의 key(name)을 적으면 해당 value 반환
		
		//전달파라미터를 요청객체req 에서 얻어오기
		String uid = req.getParameter("userid");
		String upw = req.getParameter("userpw");
		
		//전달파라미터 확인 - 콘솔창 출력
		System.out.println("uid : " + uid);
		System.out.println("upw : " + upw);
		
		//------------------------------------------------------
		
		//서블릿에서 클라이언트로 직접 응답(출력)
		//	-> JSP를 이용하지 않고 응답
		
		resp.getWriter()
			.append("<h1>전달받은 데이터</h1>")
			.append("<hr>")
			.append("<h3>아이디 : " + uid + "</h3>")
			.append("<h3>패스워드 : " + upw + "</h3>");
		
	}
}















