package login.service.impl;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import login.dao.face.LoginDao;
import login.dto.Login;
import login.service.face.LoginService;

@Service
public class LoginServiceImpl implements LoginService {

	private static final Logger logger = LoggerFactory.getLogger(LoginService.class);
	
	@Autowired LoginDao loginDao;
	
	@Override
	public void join(Login login) {
		logger.info("join() 호출 : {}", login); 
		
		loginDao.insert( login );
		
	}
	
	@Override
	public boolean login(Login login) {
		
		if( loginDao.selectCnt(login) >= 1 ) {
			return true; //인증 성공
		}
		
		return false; //인증 실패
	}
	
	@Override
	public Login info(String id) {
		return loginDao.selectById(id);
	}
	
}













