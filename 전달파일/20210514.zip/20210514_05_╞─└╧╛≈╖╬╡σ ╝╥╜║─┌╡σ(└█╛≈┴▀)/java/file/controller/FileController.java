package file.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

@Controller
public class FileController {

	private static final Logger logger = LoggerFactory.getLogger(FileController.class);
	
	
	@RequestMapping(value="/file/fileup", method=RequestMethod.GET)
	public void fileForm() {
		logger.info("/file/fileup [GET]");
	}
	
	@RequestMapping(value="/file/fileup", method=RequestMethod.POST)
	public void fileup(
			
			String title
			, @RequestParam(value="title", required=false) String t
			
			, MultipartFile file
			, @RequestParam(value="file", required=false) MultipartFile fileupload
			
			) {
		logger.info("/file/fileup [POST]");
		
		logger.info("title : {}", title);
		logger.info("t : {}", t);

		logger.info("fileupload : {}", fileupload);
		logger.info("file : {}", file);
		
	}
	
}











