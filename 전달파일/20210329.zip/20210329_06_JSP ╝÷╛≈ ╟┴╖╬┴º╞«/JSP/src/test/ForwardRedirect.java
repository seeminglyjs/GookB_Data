package test;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/forwardRedirect")
public class ForwardRedirect extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("/forwardRedirect [GET] - 접속");
		
		//------------------------------------------------
		
		//forward
//		req.getRequestDispatcher("/basictag/jsp_01.jsp")
//			.forward(req, resp);

		//외부 사이트로 연결되는 forward는 에러 발생
//		req.getRequestDispatcher("https://www.iei.or.kr/")
//			.forward(req, resp);

		//------------------------------------------------
		
		//redirect
//		resp.sendRedirect("/basictag/jsp_01.jsp");
//		resp.sendRedirect("https://www.iei.or.kr/");
		
	}
}










