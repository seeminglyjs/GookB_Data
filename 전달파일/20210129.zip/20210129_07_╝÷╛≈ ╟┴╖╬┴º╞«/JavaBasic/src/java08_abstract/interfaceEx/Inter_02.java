package java08_abstract.interfaceEx;

public interface Inter_02 {
	public abstract void out();
	
}
