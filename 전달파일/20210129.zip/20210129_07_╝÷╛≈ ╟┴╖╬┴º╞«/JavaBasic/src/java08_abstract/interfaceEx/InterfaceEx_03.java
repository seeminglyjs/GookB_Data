package java08_abstract.interfaceEx;

interface InterA {
	public abstract void getA();
}

interface InterB {
	public abstract void getB();
}

interface InterC extends InterA, InterB { //�������̽����� ��ӿ� extends
	public abstract void getC();
}

//class Child03 implements InterA, InterB, InterC {
class Child03 implements InterC {
	@Override
	public void getC() { }

	@Override
	public void getB() { }

	@Override
	public void getA() { }
	
}





public interface InterfaceEx_03 {
}
