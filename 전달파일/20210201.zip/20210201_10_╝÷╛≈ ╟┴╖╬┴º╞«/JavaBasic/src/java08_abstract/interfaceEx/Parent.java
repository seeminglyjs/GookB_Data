package java08_abstract.interfaceEx;

public class Parent extends Object {
	
	public void out() {
		System.out.println("�θ�Ŭ����");
	}
	
}
