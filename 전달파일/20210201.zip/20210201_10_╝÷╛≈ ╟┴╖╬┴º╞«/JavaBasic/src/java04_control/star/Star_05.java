package java04_control.star;

public class Star_05 {
	public static void main(String[] args) {
		
		//12345
		//12345
		//12345
		//12345
		//12345

		for(int i=0; i<5; i++) { //i, 0~4, x5, i��
			for(int j=0; j<5; j++) { //j, 0~4, x5, j��
				System.out.print(j+1); //���� ����
			}
			System.out.println();
		}
		
	}
}






