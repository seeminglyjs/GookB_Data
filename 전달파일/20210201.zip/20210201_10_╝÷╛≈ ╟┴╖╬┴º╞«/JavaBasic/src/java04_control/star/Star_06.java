package java04_control.star;

public class Star_06 {
	public static void main(String[] args) {
		
		//12345
		//23456
		//34567
		//45678
		//56789
		
		for(int i=0; i<5; i++) { //i��, 0~4, x5
			for(int j=0; j<5; j++) { //j��, 0~4, x5
				System.out.print(i+1 +j); //��+��
			}
			System.out.println(); //�ึ�� ����
		}
		
	}
}
