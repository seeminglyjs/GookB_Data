package cookie;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/cookie/update")
public class CookieUpdateController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("/cookie/update [GET] - 요청 완료");
		
		Cookie coo1 = new Cookie("ID", "boo"); //쿠키 객체 생성
		resp.addCookie( coo1 ); //클라이언트에게 쿠키 전달
		
//		Cookie coo2 = new Cookie("PASS", "4783234");
//		resp.addCookie( coo2 );

		resp.addCookie( new Cookie("PASS", "48327u") );
		
		//수정되지 않고 새로운 "name"쿠키가 추가된다
		// **쿠키의 key값은 대소문자를 구분한다
		resp.addCookie( new Cookie("name", "Bob") );
		
		req.getRequestDispatcher("/WEB-INF/views/cookie/update.jsp")
			.forward(req, resp);
	}

}








