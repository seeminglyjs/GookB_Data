package java06_class;

public class Class_03 {
	private int num;
	private String name;
	private double height;
	
	//setter
	public void setNum(int num) {
		this.num = num;
	}
	
	//getter
	public int getNum() {
		return num;
	}
	
}
