package web.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import web.dao.face.BoardDao;
import web.dto.Board;
import web.service.face.BoardService;
import web.util.Paging;

@Service
public class BoardServiceImpl implements BoardService {

	@Autowired private BoardDao boardDao;
	
	
	@Override
	public Paging getPaging(Paging inData) {
		
		//총 게시글 수 조회
		int totalCount = boardDao.selectCntAll();
		
		//페이징 계산
		Paging paging = new Paging(totalCount, inData.getCurPage());
		
		return paging;
	}
	
	@Override
	public List<Board> list(Paging paging) {
		return boardDao.selectPageList(paging);
	}
	
}















