package com.win.test.controller;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class PintleController {

	//  https://dev.giftting.co.kr:4433/my/MyGiftting.do

	//로거 객체
	private static final Logger logger = LoggerFactory.getLogger(PintleController.class); 


	//핀틀 파라미터 전달 메인 화면
	@GetMapping(value = "/pintle/main")
	public void pintleMain() {

	}

	@GetMapping(value="/pintle/gifttingweb")
	public void callGifttingWebGet() {

	}

	//기프팅 모바일 웹 호출(미구현)
	@PostMapping(value = "/pintle/gifttingweb")
	public String callGifttingWeb(HttpServletRequest rquest, Model model) {

		//연동할 URL 정보
		String strUrl = "https://dev.giftting.co.kr:4433/my/MyGiftting.do";
		String line = "";
		String data = "";

		try {
			URL url = new URL(strUrl);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();



		} catch (MalformedURLException e) {
			// url 지정오류
			e.printStackTrace();
		} catch (IOException e) {
			//url openConnection 오류
			e.printStackTrace();
		}

		return "/pintle/gifttingweb";	
	}


	//암호화 하는 화면을 보여줄 url
	@GetMapping(value= "/pintle/aes256")
	public void aes256() {

	}


	//암호화 진행하는 컨트롤러
	@PostMapping(value= "/pintle/aes256")
	public String aes256Res(HttpServletRequest request, Model model) {
		//알고리즘
		String alg = "AES/CBC/PKCS5Padding";


		String aesKey = request.getParameter("aesKey");
		String aesIv = request.getParameter("aesIv");
		String userId = request.getParameter("userId");
		String appId = request.getParameter("appId");
	
		
		//현재시간 구하기
		Date now = new Date();
		//날짜 포맷 지정
		SimpleDateFormat realNow = new SimpleDateFormat("_yyyyMMddhhmmss");
		//포맷에 따라 날짜를 문자열로 변경
		String strNow = realNow.format(now);
		logger.info("**** 현재시간 ->  " + strNow);
		
		//아이디에 시간을 추가하기
		//시간마다 암호화된 내용이 변경되게 하기 위해서
		userId += strNow;
		//appId도 시간을 더한다.
		appId += strNow; 
		
		//전달받은 키값과 IV 값 체크(+ 아이디값 체크)
		logger.info("**** Key ->  " + aesKey + " +  ***** IV ->  " + aesIv);
		logger.info("**** userId ->  " + userId);

		//알고리즘 aes-256
		try {
		
			Cipher cipher = Cipher.getInstance(alg);
			
			//키로 비밀키 생성
			SecretKeySpec keySpec = new SecretKeySpec(aesKey.getBytes(), "AES");
			//iv 로 spec 생성
			IvParameterSpec ivParamSpec = new IvParameterSpec(aesIv.getBytes());
			//암호화 적용
			cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivParamSpec);
			
			//암호화 실행
			byte[] encrypted1 = cipher.doFinal(userId.getBytes("UTF-8")); // ID 암호화
			String encId = Base64.getEncoder().encodeToString(encrypted1);
			
			byte[] encrypted2 = cipher.doFinal(appId.getBytes("UTF-8")); // app ID 암호화
			String encAppId = Base64.getEncoder().encodeToString(encrypted2);
			
			
			logger.info("암호화된 ID -> " + encId);
			
			model.addAttribute("encId", encId);
			model.addAttribute("appId", encAppId);
		
		}catch (Exception e) {
			logger.info("암호화 중 오류 발생 ");
			e.printStackTrace();
		}




		//		//----암호화 해석 코드
		//		//알고리즘 선택
		//		try {
		//			Cipher cipher = Cipher.getInstance(alg);
		//	        
		//			SecretKeySpec keySpec = new SecretKeySpec(aesIv.getBytes(), "AES");
		//	        IvParameterSpec ivParamSpec = new IvParameterSpec(aesIv.getBytes());
		//	        cipher.init(Cipher.DECRYPT_MODE, keySpec, ivParamSpec);
		//
		//	        byte[] decodedBytes = Base64.getDecoder().decode(userId);
		//	        byte[] decrypted = cipher.doFinal(decodedBytes);
		//
		//		}catch (Exception e) {
		//			e.printStackTrace();
		//		}



		return "/pintle/main";
	}



}
