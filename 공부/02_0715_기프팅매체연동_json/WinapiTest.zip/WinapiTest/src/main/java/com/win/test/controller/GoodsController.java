package com.win.test.controller;

import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
public class GoodsController {
	@GetMapping(value ="/goods/goodsSearch")
	public void goodInfo() {
		
	}
	
//	@PostMapping(value ="/goods/goodsSearch")
//	public void goodInfoRes0(HttpServletRequest request) {
//		String mdcode = request.getParameter("mdcode");
//		String goodsId = request.getParameter("goods_id");
//		
//		//�Ķ���� ����
//		if(mdcode != null) {
//			if(goodsId != null) {
//				System.out.println(mdcode);
//				System.out.println(goodsId);
//				//url�� ���� ����
//				try {
//					URL url = new URL("http://dev.giftting.co.kr:8084/media/salelist.do?mdcode=" + mdcode + "&goodsId=" + goodsId);
//					HttpURLConnection http = (HttpURLConnection) url.openConnection(); // api ��û�� �����´�.
//					
//					
//				} catch (Exception e) {
//					e.printStackTrace();
//				}		
//			}
//		}		
//	}
	
	
	@GetMapping(value="/result")
	@ResponseBody
	public HashMap<String, Object> goodInfoRes1() {
		HashMap<String,Object> map = new HashMap<>();
		map.put("test", "test");
		return map;
		
	}
	
	
	@GetMapping(value="/result2")
	@ResponseBody
	public String goodInfoRes2() {
		String test = "test";
		
		return test;
		
	}
}
