package com.win.test.controller;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class PintleController {

	//  https://dev.giftting.co.kr:4433/my/MyGiftting.do

	//핀틀 파라미터 전달 메인 화면
	@GetMapping(value = "/pintle/main")
	public void pintleMain() {
		
	}
	
	
	//기프팅 모바일 웹 호출
	@PostMapping(value = "/pintle/gifttingweb")
	public String callGifttingWeb(HttpServletRequest rquest, Model model) {
		
		//연동할 URL 정보
		String strUrl = "https://dev.giftting.co.kr:4433/my/MyGiftting.do";
		String line = "";
		String data = "";
		
		try {
			URL url = new URL(strUrl);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
						
			
			
		} catch (MalformedURLException e) {
			// url 지정오류
			e.printStackTrace();
		} catch (IOException e) {
			//url openConnection 오류
			e.printStackTrace();
		}
			
		return "/pintle/gifttingweb";	
	}
	

}
