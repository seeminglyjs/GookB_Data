package com.win.test.controller;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.win.test.dto.ApiDto;

@Controller
public class OpenApi {
	
	
	// 로거 객체
	private static final Logger logger = LoggerFactory.getLogger(OpenApi.class);
	

	@GetMapping(value="/openApi/result")
	public void openApiRes(HttpServletRequest request, Model model) {
		
		String age = request.getParameter("age");
		
		if(age == null) {
			age = "10";
		}
		
		
		String strUrl = "https://open.assembly.go.kr/portal/openapi/nzmimeepazxkubdpn"
				+ "?Key=14da0c02041b4d0f9b87762c70ddc5a6"
				+ "&Type=json"
				+ "&pIndex=1"
				+ "&pSize=100"
				+ "&AGE=" + age;
		
//		String strUrl = "https://open.assembly.go.kr/portal/openapi/nzmimeepazxkubdpn";
		String line = "";
		String data = "";
		
		try {
			URL url = new URL(strUrl);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setConnectTimeout(5000); //서버에 연결되는 Timeout 시간 설정
			con.setReadTimeout(5000); // InputStream 읽어 오는 Timeout 시간 설정
			con.setRequestMethod("POST");
			con.setDefaultUseCaches(false);
			con.setDoInput(true);
			con.setDoOutput(true);	
			con.setRequestProperty("content-type", "application/x-www-form-urlencoded");
			
			

	        //컨텐츠 타입 지정
//	       String temp = postData.toString();
//	       con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
//	       con.setRequestProperty("Content-Length", String.valueOf(temp.length()));
	        
			
//
//	        Map<String,Object> params = new HashMap<String,Object>(); // 파라미터 세팅
//	        params.put("Key", "14da0c02041b4d0f9b87762c70ddc5a6");
//	        params.put("Type", "json");
//	        params.put("pIndex", 1);
//	        params.put("pSize", 100);
//	        params.put("AGE", 10);
//	 
//	        StringBuilder postData = new StringBuilder();
//	        for(Map.Entry<String,Object> param : params.entrySet()) {
//	            if(postData.length() != 0) postData.append('&');
//	            postData.append(URLEncoder.encode(param.getKey(), "UTF-8"));
//	            postData.append('=');
//	            postData.append(URLEncoder.encode(String.valueOf(param.getValue()), "UTF-8"));
//	        }
	
//		   파라미터 전송방법 1
//	       System.out.println(postData.toString());
//		   OutputStream outputStream = con.getOutputStream();
//		   outputStream.write(postData.toString().getBytes());
//		   outputStream.flush();
//		   outputStream.close();
	   

//		    파라미터 전송방법 1.5
//	        OutputStreamWriter os = new OutputStreamWriter(con.getOutputStream(), "UTF-8");
//	        os.write(postData.toString());
//	        os.flush();
//	        os.close();   

//		    파라미터 전송방법2
//          OutputStreamWriter outStream = new OutputStreamWriter(con.getOutputStream(), "UTF-8");
//          PrintWriter writer = new PrintWriter(outStream);
//          writer.write(postData.toString());
//          logger.info(postData.toString());
//          writer.flush();
//          writer.close();
//          outStream.close();

		   
			StringBuilder sb = new StringBuilder();
			if (con.getResponseCode() == HttpURLConnection.HTTP_OK) {
				System.out.println("--공용 API 사이트 연결 성공 --");
				BufferedReader br = new BufferedReader(
						new InputStreamReader(con.getInputStream(), "utf-8"));

				while ((line = br.readLine()) != null) {
					sb.append(line).append("\n");
				}
				br.close();
				data = sb.toString(); // 최종 데이터 저장
				JSONParser jsonParser = new JSONParser();
				JSONObject jsonObject = (JSONObject) jsonParser.parse(data);
				JSONArray allList = (JSONArray) jsonObject.get("nzmimeepazxkubdpn");
				JSONObject jsonObject2 = (JSONObject) allList.get(1);
				for(int i =0; i < allList.size(); i++) {
					System.out.println("json all 정보 -> " + allList.get(i));	
				}
				System.out.println();
				System.out.println("json Object2 정보 : " + jsonObject2);
				JSONArray rowList = (JSONArray) jsonObject2.get("row");
				for(int i =0; i < rowList.size(); i++) {
					ApiDto apiDto = new ApiDto();
					JSONObject tempJson = (JSONObject) rowList.get(i);	
					apiDto.setBillName((String)tempJson.get("BILL_NAME"));
					apiDto.setAge((String)tempJson.get("AGE"));
					apiDto.setBillId((String)tempJson.get("BILL_ID"));
					apiDto.setBillNo((String)tempJson.get("BILL_No"));
					System.out.println(apiDto);
				}
				
				
				
				System.out.println();
				
				System.out.println("저장된 데이터 -> " + sb.toString());
			} else {
				System.out.println("응답메시지 ->  "+con.getResponseMessage());
			}
		} catch (Exception e){
			System.err.println("예외발생 ->  "+e.toString());
		}

		System.out.println("받은 정보 : " + data);
		model.addAttribute("openInfo", data);
		
	}
	
}
