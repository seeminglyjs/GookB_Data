package com.win.test.service.goods.face;

import java.util.List;

public interface GoodsService {

	List<String> getGoodsList(String mdcode);

}
