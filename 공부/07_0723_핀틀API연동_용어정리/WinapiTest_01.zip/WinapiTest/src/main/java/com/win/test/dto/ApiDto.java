package com.win.test.dto;

public class ApiDto {
	private String billId;
	private String billNo;
	private String billName;
	private String committee;
	private String proposeDt;
	private String procResult;
	private String age;
	private String detailLink;
	private String proposer;
	private String memberList;
	private String rstProposer;
	private String publProposer;
	private String committeeId;
	public String getBillId() {
		return billId;
	}
	public void setBillId(String billId) {
		this.billId = billId;
	}
	public String getBillNo() {
		return billNo;
	}
	public void setBillNo(String billNo) {
		this.billNo = billNo;
	}
	public String getBillName() {
		return billName;
	}
	public void setBillName(String billName) {
		this.billName = billName;
	}
	public String getCommittee() {
		return committee;
	}
	public void setCommittee(String committee) {
		this.committee = committee;
	}
	public String getProposeDt() {
		return proposeDt;
	}
	public void setProposeDt(String proposeDt) {
		this.proposeDt = proposeDt;
	}
	public String getProcResult() {
		return procResult;
	}
	public void setProcResult(String procResult) {
		this.procResult = procResult;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getDetailLink() {
		return detailLink;
	}
	public void setDetailLink(String detailLink) {
		this.detailLink = detailLink;
	}
	public String getProposer() {
		return proposer;
	}
	public void setProposer(String proposer) {
		this.proposer = proposer;
	}
	public String getMemberList() {
		return memberList;
	}
	public void setMemberList(String memberList) {
		this.memberList = memberList;
	}
	public String getRstProposer() {
		return rstProposer;
	}
	public void setRstProposer(String rstProposer) {
		this.rstProposer = rstProposer;
	}
	public String getPublProposer() {
		return publProposer;
	}
	public void setPublProposer(String publProposer) {
		this.publProposer = publProposer;
	}
	public String getCommitteeId() {
		return committeeId;
	}
	public void setCommitteeId(String committeeId) {
		this.committeeId = committeeId;
	}
	@Override
	public String toString() {
		return "ApiDto [billId=" + billId + ", billNo=" + billNo + ", billName=" + billName + ", committee=" + committee
				+ ", proposeDt=" + proposeDt + ", procResult=" + procResult + ", age=" + age + ", detailLink="
				+ detailLink + ", proposer=" + proposer + ", memberList=" + memberList + ", rstProposer=" + rstProposer
				+ ", publProposer=" + publProposer + ", committeeId=" + committeeId + "]";
	}
	
	
}
