package com.win.test.controller;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class PintleController {

	//  https://dev.giftting.co.kr:4433/my/MyGiftting.do

	//로거 객체
	private static final Logger logger = LoggerFactory.getLogger(PintleController.class); 


	//핀틀 파라미터 전달 메인 화면
	@GetMapping(value = "/pintle/main")
	public void pintleMain() {

	}

	@GetMapping(value="/pintle/gifttingweb")
	public void callGifttingWebGet() {

	}

	//기프팅 모바일 웹 호출(미구현)
	@PostMapping(value = "/pintle/gifttingweb")
	public String callGifttingWeb(HttpServletRequest rquest, Model model) {

		//연동할 URL 정보
		String strUrl = "https://dev.giftting.co.kr:4433/my/MyGiftting.do";
		String line = "";
		String data = "";

		try {
			URL url = new URL(strUrl);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();



		} catch (MalformedURLException e) {
			// url 지정오류
			e.printStackTrace();
		} catch (IOException e) {
			//url openConnection 오류
			e.printStackTrace();
		}

		return "/pintle/gifttingweb";	
	}


	//암호화 하는 화면을 보여줄 url
	@GetMapping(value= "/pintle/aes256")
	public void aes256() {

	}


	//암호화 진행하는 컨트롤러
	@PostMapping(value= "/pintle/aes256")
	public String aes256Res(HttpServletRequest request, Model model) {
		//알고리즘
		String alg = "AES/CBC/PKCS5Padding";

		//암호화를 위해 전달받은 파라미터(예외체크 안함)
		String aesKey = request.getParameter("aesKey");
		String aesIv = request.getParameter("aesIv");
		String userId = request.getParameter("userId");
		String appId = request.getParameter("appId");


		//현재시간 구하기
		Date now = new Date();
		//날짜 포맷 지정
		SimpleDateFormat realNow = new SimpleDateFormat("_yyyyMMddHHmmss");
		//포맷에 따라 날짜를 문자열로 변경
		String strNow = realNow.format(now);
		logger.info("**** 현재시간 ->  " + strNow);

		//아이디에 시간을 추가하기
		//시간마다 암호화된 내용이 변경되게 하기 위해서
		userId += strNow;
		//appId도 시간을 더한다.
		appId += strNow; 

		//전달받은 키값과 IV 값 체크(+ 아이디값 체크)
		logger.info("**** Key ->  " + aesKey + " +  ***** IV ->  " + aesIv);
		logger.info("**** userId ->  " + userId);

		//알고리즘 aes-256
		try {

			Cipher cipher = Cipher.getInstance(alg);

			//키로 비밀키 생성
			SecretKeySpec keySpec = new SecretKeySpec(aesKey.getBytes(), "AES");
			//iv 로 spec 생성
			IvParameterSpec ivParamSpec = new IvParameterSpec(aesIv.getBytes());
			//암호화 적용
			cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivParamSpec);

			//암호화 실행
			byte[] encrypted1 = cipher.doFinal(userId.getBytes("UTF-8")); // ID 암호화
			String encId = Base64.getEncoder().encodeToString(encrypted1);

			byte[] encrypted2 = cipher.doFinal(appId.getBytes("UTF-8")); // app ID 암호화
			String encAppId = Base64.getEncoder().encodeToString(encrypted2);


			logger.info("암호화된 ID -> " + encId);

			model.addAttribute("encId", encId);
			model.addAttribute("appId", encAppId);

		}catch (Exception e) {
			logger.info("암호화 중 오류 발생 ");
			e.printStackTrace();
		}

		//		//----암호화 해석 코드
		//		//알고리즘 선택
		//		try {
		//			Cipher cipher = Cipher.getInstance(alg);
		//	        
		//			SecretKeySpec keySpec = new SecretKeySpec(aesIv.getBytes(), "AES");
		//	        IvParameterSpec ivParamSpec = new IvParameterSpec(aesIv.getBytes());
		//	        cipher.init(Cipher.DECRYPT_MODE, keySpec, ivParamSpec);
		//
		//	        byte[] decodedBytes = Base64.getDecoder().decode(userId);
		//	        byte[] decrypted = cipher.doFinal(decodedBytes);
		//
		//		}catch (Exception e) {
		//			e.printStackTrace();
		//		}

		return "/pintle/main";
	}


	//핀틀 포인트 조회 form 화면
	@GetMapping(value="/pintle/getpoint")
	public void pintleGetPoint() {

	}

	//핀틀 포인트 조회 값 처리 컨트롤러
	@SuppressWarnings("unchecked")
	@PostMapping(value ="/pintle/getpoint")
	public String pintlePostPoint(HttpServletRequest request, Model model) {

		String jsonForm = request.getParameter("jsonForm");
		logger.info(jsonForm);

		//전달받은 제이슨 정보를 제이슨 객체화
		try {
			JSONParser jsonParser = new JSONParser();
			JSONObject jsonObj = (JSONObject) jsonParser.parse(jsonForm);

			String userId = (String) jsonObj.get("buyUserId");

			//userId 체크
			if(userId.equals("seeminglyjs")) {
				JSONObject jsonObj2 = new JSONObject();

				jsonObj2.put("code", "000");
				jsonObj2.put("msg", "성공");
				jsonObj2.put("id", "seeminglyjs");
				jsonObj2.put("cash", "30000");

				model.addAttribute("jsonObj", jsonObj2);
				
			}else if(userId.equals("seeminglyjs2")) {
				JSONObject jsonObj2 = new JSONObject();

				jsonObj2.put("code", "000");
				jsonObj2.put("msg", "성공");
				jsonObj2.put("id", "seeminglyjs2");
				jsonObj2.put("cash", "35000");
				
				model.addAttribute("jsonObj", jsonObj2);

			}else if(userId.equals("seeminglyjs3")) {
				JSONObject jsonObj2 = new JSONObject();

				jsonObj2.put("code", "000");
				jsonObj2.put("msg", "성공");
				jsonObj2.put("id", "seeminglyjs3");
				jsonObj2.put("cash", "45000");
				model.addAttribute("jsonObj", jsonObj2);

			}else if(userId.equals("seeminglyjs4")) {
				JSONObject jsonObj2 = new JSONObject();

				jsonObj2.put("code", "000");
				jsonObj2.put("msg", "성공");
				jsonObj2.put("id", "seeminglyjs4");
				jsonObj2.put("cash", "55000");
				
				model.addAttribute("jsonObj", jsonObj2);
			}else {
				JSONObject jsonObj2 = new JSONObject();

				jsonObj2.put("code", "999");
				jsonObj2.put("msg", "실패");
				jsonObj2.put("id", "존재하지 않음");
				jsonObj2.put("cash", "00000");
				
				model.addAttribute("jsonObj", jsonObj2);
			}


		} catch (Exception e) {
			//제이슨 형변환 오류 체크
			e.printStackTrace();
		}
		return "/pintle/getPointResult";
	}

	//핀틀 포인트 차감 메소드
	@GetMapping(value= "/pintle/minusPoint")
	public void pintleMinusPoint() {
		
	}
	

	//핀틀 포인트 조회 값 처리 컨트롤러
	@SuppressWarnings("unchecked")
	@PostMapping(value ="/pintle/minusPoint")
	public String pintleMinusPointRes(HttpServletRequest request, Model model) {

		String jsonForm = request.getParameter("jsonForm");
		logger.info(jsonForm);

		//전달받은 제이슨 정보를 제이슨 객체화
		try {
			JSONParser jsonParser = new JSONParser();
			JSONObject jsonObj = (JSONObject) jsonParser.parse(jsonForm);

			String userId = (String) jsonObj.get("id");
			String payNo = (String) jsonObj.get("payNo");
			String price = (String) jsonObj.get("price");
			
			//userId 체크
			if(userId.equals("seeminglyjs")) {
				JSONObject jsonObj2 = new JSONObject();
				
				int cash = 99999999;
				
				cash = cash - Integer.parseInt(price);
							
				jsonObj2.put("code", "000");
				jsonObj2.put("msg", "성공");
				jsonObj2.put("id", "seeminglyjs");
				jsonObj2.put("paymnet", "Y");
				jsonObj2.put("payment_id", payNo);
				jsonObj2.put("payment_cash", cash);
				
				model.addAttribute("jsonObj", jsonObj2);
				
			}else if(userId.equals("seeminglyjs2")) {
				JSONObject jsonObj2 = new JSONObject();
				
				int cash = 99999999;
				
				cash = cash - Integer.parseInt(price);
							
				jsonObj2.put("code", "000");
				jsonObj2.put("msg", "성공");
				jsonObj2.put("id", "seeminglyjs");
				jsonObj2.put("paymnet", "Y");
				jsonObj2.put("payment_id", payNo);
				jsonObj2.put("payment_cash", cash);
				
				model.addAttribute("jsonObj", jsonObj2);
			}else if(userId.equals("seeminglyjs3")) {
				JSONObject jsonObj2 = new JSONObject();
				
				int cash = 99999999;
				
				cash = cash - Integer.parseInt(price);
							
				jsonObj2.put("code", "000");
				jsonObj2.put("msg", "성공");
				jsonObj2.put("id", "seeminglyjs");
				jsonObj2.put("paymnet", "Y");
				jsonObj2.put("payment_id", payNo);
				jsonObj2.put("payment_cash", cash);
				
				model.addAttribute("jsonObj", jsonObj2);

			}else if(userId.equals("seeminglyjs4")) {
				JSONObject jsonObj2 = new JSONObject();
				
				int cash = 99999999;
				
				cash = cash - Integer.parseInt(price);
							
				jsonObj2.put("code", "000");
				jsonObj2.put("msg", "성공");
				jsonObj2.put("id", "seeminglyjs");
				jsonObj2.put("paymnet", "Y");
				jsonObj2.put("payment_id", payNo);
				jsonObj2.put("payment_cash", cash);
				
				model.addAttribute("jsonObj", jsonObj2);
			}else {
				JSONObject jsonObj2 = new JSONObject();

				jsonObj2.put("code", "999");
				jsonObj2.put("msg", "실패");
				jsonObj2.put("id", "존재하지 않음");
				jsonObj2.put("paymnet", "N");
				jsonObj2.put("payment_id", "없음");
				jsonObj2.put("payment_cash", "000000");
				
				model.addAttribute("jsonObj", jsonObj2);
			}


		} catch (Exception e) {
			//제이슨 형변환 오류 체크
			e.printStackTrace();
		}
		return "/pintle/minusPointRes";
	}
	
	
}
