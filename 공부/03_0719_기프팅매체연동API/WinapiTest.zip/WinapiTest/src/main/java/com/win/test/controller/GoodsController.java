package com.win.test.controller;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

import com.win.test.service.goods.face.GoodsService;

@Controller
public class GoodsController { //mdcode는 무조건 channel로 고정이다.

	@Autowired
	GoodsService goodsService;

	// 로거 객체
	private static final Logger logger = LoggerFactory.getLogger(GoodsController.class);

	@GetMapping(value ="/goods/goodsSearch")
	public void goodInfo() {

	}

	//	@PostMapping(value ="/goods/goodsSearch")
	//	public void goodInfoRes0(HttpServletRequest request) {
	//		String mdcode = request.getParameter("mdcode");
	//		String goodsId = request.getParameter("goods_id");
	//		
	//		//�Ķ���� ����
	//		if(mdcode != null) {
	//			if(goodsId != null) {
	//				System.out.println(mdcode);
	//				System.out.println(goodsId);
	//				//url�� ���� ����
	//				try {
	//					URL url = new URL("http://dev.giftting.co.kr:8084/media/salelist.do?mdcode=" + mdcode + "&goodsId=" + goodsId);
	//					HttpURLConnection http = (HttpURLConnection) url.openConnection(); // api ��û�� �����´�.
	//					
	//					
	//				} catch (Exception e) {
	//					e.printStackTrace();
	//				}		
	//			}
	//		}		
	//	}


	// Goods search API connection
	@PostMapping(value="/goods/goodsSearch")
	public String goodInfoRes(HttpServletRequest request, Model model) {
		String mdcode = request.getParameter("mdcode");
		String goodsId = request.getParameter("goodsId");

		//		if(mdcode != null) {
		//			List<String> goodList = goodsService.getGoodsList(mdcode);
		//		}else {
		//			return "redirect:/goods/goodsSearch";
		//		}	

		if(mdcode != null) {
		}else {
			return "redirect:/goods/goodsSearch";
		}	

		String strUrl = "http://dev.giftting.co.kr:8084/media/salelist.do?response_type=JSON&";
		String line = "";
		String data = "";

		try {
			URL url = new URL(strUrl);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setConnectTimeout(25000); //서버에 연결되는 Timeout 시간 설정
			con.setReadTimeout(25000); // InputStream 읽어 오는 Timeout 시간 설정
			con.setRequestMethod("POST");
			con.setDoInput(true);
			con.setDoOutput(true);
			con.setRequestProperty("content-type", "application/x-www-form-urlencoded");

			Map<String,Object> params = new HashMap<>(); // 파라미터 세팅
			params.put("mdcode", mdcode);
			if(goodsId != null) {
				params.put("goods_id", goodsId);
			}


			StringBuilder postData = new StringBuilder();
			for(Map.Entry<String,Object> param : params.entrySet()) {
				if(postData.length() != 0) postData.append('&');
				postData.append(URLEncoder.encode(param.getKey(), "UTF-8"));
				postData.append('=');
				postData.append(URLEncoder.encode(String.valueOf(param.getValue()), "UTF-8"));
			}
			//byte[] postDataBytes = postData.toString().getBytes("UTF-8"); 

			//	파라미터 전송방법 2
			OutputStreamWriter outStream = new OutputStreamWriter(con.getOutputStream(), "UTF-8");
			PrintWriter writer = new PrintWriter(outStream);
			writer.write(postData.toString());
			logger.info(postData.toString());
			writer.flush();
			writer.close();
			outStream.close();

			StringBuilder sb = new StringBuilder();
			if (con.getResponseCode() == HttpURLConnection.HTTP_OK) {
				logger.info("--상품조회 API 사이트 연결 성공 --");
				logger.info("컨텐츠 길이 -> " + con.getContentLength());
				logger.info("상태코드 -> " + con.getResponseCode());
				logger.info("응답 메시지 -> " + con.getResponseMessage());
				System.out.println();
				BufferedReader br = new BufferedReader(
						new InputStreamReader(con.getInputStream(), "EUC-KR"));
				while ((line = br.readLine()) != null) {
					sb.append(line).append("\n");
				}
				br.close();
				data = sb.toString(); // 최종 데이터 저장
				JSONParser jsonParser = new JSONParser();
				JSONObject jsonObject = (JSONObject) jsonParser.parse(data);
				JSONArray goodList = (JSONArray) jsonObject.get("goods_list");
				List<JSONObject> list = new ArrayList<>();

				//리스트에 해당 JSONObject 정보를 담는다.
				for(int i = 0; i < goodList.size(); i++) {
					list.add((JSONObject) goodList.get(i));
				}

				//객체를 넘겨준다.
				model.addAttribute("list", list);
				model.addAttribute("listSize", list.size()-1);
			} else {
				System.out.println(con.getErrorStream());
				System.out.println("응답 메시지 -> " + con.getResponseMessage());
			}
		} catch (Exception e){
			System.err.println(e.toString());
		}

		return "/goods/result";
	}




	// Coupon send API connection
	@PostMapping(value="/coupon/result")
	public String cuponSendRes(HttpServletRequest request, Model model) {
		String mdcode = request.getParameter("mdcode");
		String msg = request.getParameter("msg");
		String title = request.getParameter("title");
		String callback = request.getParameter("callback");
		String goodsId = request.getParameter("goodsId");
		String trId = request.getParameter("trId");
		String gubun = request.getParameter("gubun");
		//		if(mdcode != null) {
		//			List<String> goodList = goodsService.getGoodsList(mdcode);
		//		}else {
		//			return "redirect:/goods/goodsSearch";
		//		}	

		if(mdcode != null) {
		}else {
			return "redirect:/goods/goodsSearch";
		}	

		String strUrl = "http://dev.giftting.co.kr:8084/media/request.do?response_type=JSON&";
		String line = "";
		String data = "";

		try {
			URL url = new URL(strUrl);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setConnectTimeout(5000); //서버에 연결되는 Timeout 시간 설정
			con.setReadTimeout(5000); // InputStream 읽어 오는 Timeout 시간 설정
			con.setDoInput(true);
			con.setDoOutput(true);
			con.setRequestMethod("POST");



			Map<String,Object> params = new HashMap<String,Object>();
			params.put("mdcode", mdcode);
			params.put("msg", msg);
			params.put("title", title);
			params.put("callback", callback);
			params.put("goods_id", goodsId);
			params.put("tr_id", trId);
			params.put("gubun", gubun);


			StringBuilder postData = new StringBuilder();
			for(Map.Entry<String,Object> param : params.entrySet()) {
				if(postData.length() != 0) postData.append('&');
				postData.append(URLEncoder.encode(param.getKey(), "UTF-8"));
				postData.append('=');
				postData.append(URLEncoder.encode(String.valueOf(param.getValue()), "UTF-8"));
			}



			//			  파라미터 전송방법 2
			OutputStreamWriter outStream = new OutputStreamWriter(con.getOutputStream(), "UTF-8");
			PrintWriter writer = new PrintWriter(outStream);
			writer.write(postData.toString());
			writer.flush();
			writer.close();
			outStream.close();
			con.connect();

			StringBuilder sb = new StringBuilder();
			if (con.getResponseCode() == HttpURLConnection.HTTP_OK) {
				System.out.println("-- 쿠폰 발송 API 사이트 연결 성공 --");
				BufferedReader br = new BufferedReader(
						new InputStreamReader(con.getInputStream(), "utf-8"));

				while ((line = br.readLine()) != null) {
					sb.append(line).append("\n");
				}
				br.close();
				data = sb.toString();
				JSONParser jsonParser = new JSONParser();
				JSONObject jsonObject = (JSONObject) jsonParser.parse(data);
				
				logger.info(""+jsonObject);
				model.addAttribute("jsonObj", jsonObject);

			} else {
				System.out.println(con.getResponseMessage());
			}
		} catch (Exception e){
			System.err.println(e.toString());
		}

		return "/coupon/result";
	}

	
	// 쿠폰 취소하는 API
	@PostMapping(value="/coupon/revoke")
	public String cuponRevokeRes(HttpServletRequest request, Model model) {
		String mdcode = request.getParameter("mdcode");
		String trId = request.getParameter("trId");
		//		if(mdcode != null) {
		//			List<String> goodList = goodsService.getGoodsList(mdcode);
		//		}else {
		//			return "redirect:/goods/goodsSearch";
		//		}	

		if(mdcode != null) {
		}else {
			return "redirect:/goods/goodsSearch";
		}	

		String strUrl = "http://dev.giftting.co.kr:8084/media/coupon_cancel.do?response_type=JSON&";
		String line = "";
		String data = "";

		try {
			URL url = new URL(strUrl);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setConnectTimeout(5000); //서버에 연결되는 Timeout 시간 설정
			con.setReadTimeout(5000); // InputStream 읽어 오는 Timeout 시간 설정
			con.setDoInput(true);
			con.setDoOutput(true);
			con.setRequestMethod("POST");



			Map<String,Object> params = new HashMap<String,Object>();
			params.put("mdcode", mdcode);
			params.put("tr_id", trId);


			StringBuilder postData = new StringBuilder();
			for(Map.Entry<String,Object> param : params.entrySet()) {
				if(postData.length() != 0) postData.append('&');
				postData.append(URLEncoder.encode(param.getKey(), "UTF-8"));
				postData.append('=');
				postData.append(URLEncoder.encode(String.valueOf(param.getValue()), "UTF-8"));
			}
			
			//			  파라미터 전송방법 2
			OutputStreamWriter outStream = new OutputStreamWriter(con.getOutputStream(), "UTF-8");
			PrintWriter writer = new PrintWriter(outStream);
			writer.write(postData.toString());
			writer.flush();
			writer.close();
			outStream.close();
			con.connect();

			StringBuilder sb = new StringBuilder();
			if (con.getResponseCode() == HttpURLConnection.HTTP_OK) {
				System.out.println("-- 쿠폰 취소 API 사이트 연결 성공 --");
				BufferedReader br = new BufferedReader(
						new InputStreamReader(con.getInputStream(), "utf-8"));

				while ((line = br.readLine()) != null) {
					sb.append(line).append("\n");
				}
				br.close();
				data = sb.toString();
				JSONParser jsonParser = new JSONParser();
				JSONObject jsonObject = (JSONObject) jsonParser.parse(data);
				
				logger.info(""+jsonObject);
				model.addAttribute("jsonObj", jsonObject);

			} else {
				System.out.println(con.getResponseMessage());
			}
		} catch (Exception e){
			System.err.println(e.toString());
		}

		return "/coupon/revoke";
	}

	



	//발행 쿠폰 상태 확인 API
	@PostMapping(value="/coupon/couponStatus")
	public String couponStatusRes(HttpServletRequest request, Model model) {
		String mdcode = request.getParameter("mdcode");
		String trId = request.getParameter("trId");

		//		if(mdcode != null) {
		//			List<String> goodList = goodsService.getGoodsList(mdcode);
		//		}else {
		//			return "redirect:/goods/goodsSearch";
		//		}	

		if(mdcode != null || trId != null) {
		}else {
			return "redirect:/goods/goodsSearch";
		}	

		String strUrl = "http://dev.giftting.co.kr:8084/media/coupon_status.do?response_type=JSON&";
		String line = "";
		String data = "";

		try {
			URL url = new URL(strUrl);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setConnectTimeout(25000); //서버에 연결되는 Timeout 시간 설정
			con.setReadTimeout(25000); // InputStream 읽어 오는 Timeout 시간 설정
			con.setRequestMethod("POST");
			con.setDoInput(true);
			con.setDoOutput(true);
			con.setRequestProperty("content-type", "application/x-www-form-urlencoded");

			Map<String,Object> params = new HashMap<>(); // 파라미터 세팅
			params.put("mdcode", mdcode);
			params.put("tr_id", trId);


			StringBuilder postData = new StringBuilder();
			for(Map.Entry<String,Object> param : params.entrySet()) {
				if(postData.length() != 0) postData.append('&');
				postData.append(URLEncoder.encode(param.getKey(), "UTF-8"));
				postData.append('=');
				postData.append(URLEncoder.encode(String.valueOf(param.getValue()), "UTF-8"));
			}
			//byte[] postDataBytes = postData.toString().getBytes("UTF-8"); 

			//			  파라미터 전송방법 2
			OutputStreamWriter outStream = new OutputStreamWriter(con.getOutputStream(), "UTF-8");
			PrintWriter writer = new PrintWriter(outStream);
			writer.write(postData.toString());
			logger.info(postData.toString());
			writer.flush();
			writer.close();
			outStream.close();

			StringBuilder sb = new StringBuilder();
			if (con.getResponseCode() == HttpURLConnection.HTTP_OK) {
				logger.info("--쿠폰 상태 조회 API 사이트 연결 성공 --");
				logger.info("컨텐츠 길이 -> " + con.getContentLength());
				logger.info("상태코드 -> " + con.getResponseCode());
				logger.info("응답 메시지 -> " + con.getResponseMessage());
				System.out.println();
				BufferedReader br = new BufferedReader(
						new InputStreamReader(con.getInputStream(), "EUC-KR"));
				while ((line = br.readLine()) != null) {
					sb.append(line).append("\n");
				}
				br.close();
				data = sb.toString(); // 최종 데이터 저장
				JSONParser jsonParser = new JSONParser();
				JSONObject jsonObject = (JSONObject) jsonParser.parse(data);

				System.out.println(jsonObject);
				//객체를 넘겨준다.
				model.addAttribute("jsonObj", jsonObject);
			} else {
				System.out.println(con.getErrorStream());
				System.out.println("응답 메시지 -> " + con.getResponseMessage());
			}
		} catch (Exception e){
			System.err.println(e.toString());
		}

		return "/coupon/couponStatus";
	}


	//상품 상태 확인 API
	@PostMapping(value="/goods/goodsStatus")
	public String goodsStatusRes(HttpServletRequest request, Model model) {
		String mdcode = request.getParameter("mdcode");
		String goodsId = request.getParameter("goodsId");

		//		if(mdcode != null) {
		//			List<String> goodList = goodsService.getGoodsList(mdcode);
		//		}else {
		//			return "redirect:/goods/goodsSearch";
		//		}	

		if(mdcode != null || goodsId != null) {
		}else {
			return "redirect:/goods/goodsSearch";
		}	

		String strUrl = "http://dev.giftting.co.kr:8084/media/check_goods.do?response_type=JSON&";
		String line = "";
		String data = "";

		try {
			URL url = new URL(strUrl);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setConnectTimeout(25000); //서버에 연결되는 Timeout 시간 설정
			con.setReadTimeout(25000); // InputStream 읽어 오는 Timeout 시간 설정
			con.setRequestMethod("POST");
			con.setDoInput(true);
			con.setDoOutput(true);
			con.setRequestProperty("content-type", "application/x-www-form-urlencoded");

			Map<String,Object> params = new HashMap<>(); // 파라미터 세팅
			params.put("mdcode", mdcode);
			params.put("goods_id", goodsId);


			StringBuilder postData = new StringBuilder();
			for(Map.Entry<String,Object> param : params.entrySet()) {
				if(postData.length() != 0) postData.append('&');
				postData.append(URLEncoder.encode(param.getKey(), "UTF-8"));
				postData.append('=');
				postData.append(URLEncoder.encode(String.valueOf(param.getValue()), "UTF-8"));
			}
			//byte[] postDataBytes = postData.toString().getBytes("UTF-8"); 

			//			  파라미터 전송방법 2
			OutputStreamWriter outStream = new OutputStreamWriter(con.getOutputStream(), "UTF-8");
			PrintWriter writer = new PrintWriter(outStream);
			writer.write(postData.toString());
			logger.info(postData.toString());
			writer.flush();
			writer.close();
			outStream.close();

			StringBuilder sb = new StringBuilder();
			if (con.getResponseCode() == HttpURLConnection.HTTP_OK) {
				logger.info("--상품 상태 조회 API 사이트 연결 성공 --");
				logger.info("컨텐츠 길이 -> " + con.getContentLength());
				logger.info("상태코드 -> " + con.getResponseCode());
				logger.info("응답 메시지 -> " + con.getResponseMessage());
				System.out.println();
				BufferedReader br = new BufferedReader(
						new InputStreamReader(con.getInputStream(), "EUC-KR"));
				while ((line = br.readLine()) != null) {
					sb.append(line).append("\n");
				}
				br.close();
				data = sb.toString(); // 최종 데이터 저장
				JSONParser jsonParser = new JSONParser();
				JSONObject jsonObject = (JSONObject) jsonParser.parse(data);
				JSONArray allList = (JSONArray) jsonObject.get("goodslist");
				List<JSONObject> list = new ArrayList<JSONObject>();

				for(int i = 0; i < allList.size(); i++) {
					list.add((JSONObject) allList.get(i));
				}

				System.out.println(jsonObject);
				//객체를 넘겨준다.
				model.addAttribute("list", list);
				model.addAttribute("listSize", list.size()- 1);
			} else {
				System.out.println(con.getErrorStream());
				System.out.println("응답 메시지 -> " + con.getResponseMessage());
			}
		} catch (Exception e){
			System.err.println(e.toString());
		}

		return "/goods/goodsStatus";
	}


	//잔여 한도 확인 API
	@PostMapping(value="/balance/checkBalance")
	public String checkBalanceRes(HttpServletRequest request, Model model) {
		String mdcode = request.getParameter("mdcode");

		//		if(mdcode != null) {
		//			List<String> goodList = goodsService.getGoodsList(mdcode);
		//		}else {
		//			return "redirect:/goods/goodsSearch";
		//		}	

		if(mdcode != null) {
		}else {
			return "redirect:/goods/goodsSearch";
		}	

		String strUrl = "http://dev.giftting.co.kr:8084/media/check_balance.do?response_type=JSON&";
		String line = "";
		String data = "";

		try {
			URL url = new URL(strUrl);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();
			con.setConnectTimeout(25000); //서버에 연결되는 Timeout 시간 설정
			con.setReadTimeout(25000); // InputStream 읽어 오는 Timeout 시간 설정
			con.setRequestMethod("POST");
			con.setDoInput(true);
			con.setDoOutput(true);
			con.setRequestProperty("content-type", "application/x-www-form-urlencoded");

			Map<String,Object> params = new HashMap<>(); // 파라미터 세팅
			params.put("mdcode", mdcode);

			StringBuilder postData = new StringBuilder();
			for(Map.Entry<String,Object> param : params.entrySet()) {
				if(postData.length() != 0) postData.append('&');
				postData.append(URLEncoder.encode(param.getKey(), "UTF-8"));
				postData.append('=');
				postData.append(URLEncoder.encode(String.valueOf(param.getValue()), "UTF-8"));
			}
			//byte[] postDataBytes = postData.toString().getBytes("UTF-8"); 

			//			  파라미터 전송방법 2
			OutputStreamWriter outStream = new OutputStreamWriter(con.getOutputStream(), "UTF-8");
			PrintWriter writer = new PrintWriter(outStream);
			writer.write(postData.toString());
			logger.info(postData.toString());
			writer.flush();
			writer.close();
			outStream.close();

			StringBuilder sb = new StringBuilder();
			if (con.getResponseCode() == HttpURLConnection.HTTP_OK) {
				logger.info("--잔여 한도 조회 API 사이트 연결 성공 --");
				logger.info("컨텐츠 길이 -> " + con.getContentLength());
				logger.info("상태코드 -> " + con.getResponseCode());
				logger.info("응답 메시지 -> " + con.getResponseMessage());
				System.out.println();
				BufferedReader br = new BufferedReader(
						new InputStreamReader(con.getInputStream(), "EUC-KR"));
				while ((line = br.readLine()) != null) {
					sb.append(line).append("\n");
				}
				br.close();
				data = sb.toString(); // 최종 데이터 저장
				JSONParser jsonParser = new JSONParser();
				JSONObject jsonObject = (JSONObject) jsonParser.parse(data);

				System.out.println(jsonObject);
				//객체를 넘겨준다.
				model.addAttribute("jsonObj", jsonObject);
			} else {
				System.out.println(con.getErrorStream());
				System.out.println("응답 메시지 -> " + con.getResponseMessage());
			}
		} catch (Exception e){
			System.err.println(e.toString());
		}

		return "/balance/checkBalance";
	}



	//	@GetMapping(value="/result")
	//	@ResponseBody
	//	public HashMap<String, Object> goodInfoRes1() {
	//		HashMap<String,Object> map = new HashMap<>();
	//		map.put("test", "test");
	//		return map;
	//		
	//	}
	//	
	//	
	//	@GetMapping(value="/result2")
	//	@ResponseBody
	//	public String goodInfoRes2() {
	//		String test = "test";
	//		
	//		return test;
	//		
	//	}




}
