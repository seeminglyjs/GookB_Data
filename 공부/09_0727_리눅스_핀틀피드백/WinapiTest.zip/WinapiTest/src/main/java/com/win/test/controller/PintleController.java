package com.win.test.controller;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import javax.servlet.http.HttpServletRequest;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;

@Controller
public class PintleController {

	//  https://dev.giftting.co.kr:4433/my/MyGiftting.do

	//로거 객체
	private static final Logger logger = LoggerFactory.getLogger(PintleController.class); 


	//핀틀 파라미터 전달 메인 화면
	@GetMapping(value = "/pintle/main")
	public void pintleMain() {

	}

	@GetMapping(value="/pintle/gifttingweb")
	public void callGifttingWebGet() {

	}

	//기프팅 모바일 웹 호출(미구현)
	@PostMapping(value = "/pintle/gifttingweb")
	public String callGifttingWeb(HttpServletRequest rquest, Model model) {

		//연동할 URL 정보
		String strUrl = "https://dev.giftting.co.kr:4433/my/MyGiftting.do";
		String line = "";
		String data = "";

		try {
			URL url = new URL(strUrl);
			HttpURLConnection con = (HttpURLConnection) url.openConnection();



		} catch (MalformedURLException e) {
			// url 지정오류
			e.printStackTrace();
		} catch (IOException e) {
			//url openConnection 오류
			e.printStackTrace();
		}

		return "/pintle/gifttingweb";	
	}


	//암호화 하는 화면을 보여줄 url
	@GetMapping(value= "/pintle/aes256")
	public void aes256() {

	}


	//암호화 진행하는 컨트롤러
	@PostMapping(value= "/pintle/aes256")
	public String aes256Res(HttpServletRequest request, Model model) {
		//알고리즘
		String alg = "AES/CBC/PKCS5Padding";

		//암호화를 위해 전달받은 파라미터(예외체크 안함)
		String aesKey = request.getParameter("aesKey");
		String aesIv = request.getParameter("aesIv");
		String userId = request.getParameter("userId");
		String appId = request.getParameter("appId");


		//현재시간 구하기
		Date now = new Date();
		//날짜 포맷 지정
		SimpleDateFormat realNow = new SimpleDateFormat("_yyyyMMddHHmmss");
		//포맷에 따라 날짜를 문자열로 변경
		String strNow = realNow.format(now);
		logger.info("**** 현재시간 ->  " + strNow);

		//아이디에 시간을 추가하기
		//시간마다 암호화된 내용이 변경되게 하기 위해서
		userId += strNow;
		//appId도 시간을 더한다.
		appId += strNow; 

		//전달받은 키값과 IV 값 체크(+ 아이디값 체크)
		logger.info("**** Key ->  " + aesKey + " +  ***** IV ->  " + aesIv);
		logger.info("**** userId ->  " + userId);

		//알고리즘 aes-256
		try {

			Cipher cipher = Cipher.getInstance(alg);

			//키로 비밀키 생성
			SecretKeySpec keySpec = new SecretKeySpec(aesKey.getBytes(), "AES");
			//iv 로 spec 생성
			IvParameterSpec ivParamSpec = new IvParameterSpec(aesIv.getBytes());
			//암호화 적용
			cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivParamSpec);

			//암호화 실행
			byte[] encrypted1 = cipher.doFinal(userId.getBytes("UTF-8")); // ID 암호화
			String encId = Base64.getEncoder().encodeToString(encrypted1);

			byte[] encrypted2 = cipher.doFinal(appId.getBytes("UTF-8")); // app ID 암호화
			String encAppId = Base64.getEncoder().encodeToString(encrypted2);


			logger.info("암호화된 ID -> " + encId);

			model.addAttribute("encId", encId);
			model.addAttribute("appId", encAppId);

		}catch (Exception e) {
			logger.info("암호화 중 오류 발생 ");
			e.printStackTrace();
		}

		//		//----암호화 해석 코드
		//		//알고리즘 선택
		//		try {
		//			Cipher cipher = Cipher.getInstance(alg);
		//	        
		//			SecretKeySpec keySpec = new SecretKeySpec(aesIv.getBytes(), "AES");
		//	        IvParameterSpec ivParamSpec = new IvParameterSpec(aesIv.getBytes());
		//	        cipher.init(Cipher.DECRYPT_MODE, keySpec, ivParamSpec);
		//
		//	        byte[] decodedBytes = Base64.getDecoder().decode(userId);
		//	        byte[] decrypted = cipher.doFinal(decodedBytes);
		//
		//		}catch (Exception e) {
		//			e.printStackTrace();
		//		}

		return "/pintle/main";
	}


	//핀틀 포인트 조회 form 화면
	@GetMapping(value="/pintle/getpoint")
	public void pintleGetPoint() {

	}

	//핀틀 포인트 조회 값 처리 컨트롤러
	@SuppressWarnings("unchecked")
	@PostMapping(value ="/pintle/getpoint")
	public String pintlePostPoint(HttpServletRequest request, Model model) {

		String jsonForm = request.getParameter("jsonForm");
		logger.info(jsonForm);

		//전달받은 제이슨 정보를 제이슨 객체화
		try {
			JSONParser jsonParser = new JSONParser();
			JSONObject jsonObj = (JSONObject) jsonParser.parse(jsonForm);

			String userId = (String) jsonObj.get("buyUserId");

			//userId 체크
			if(userId.equals("seeminglyjs")) {
				JSONObject jsonObj2 = new JSONObject();

				jsonObj2.put("code", "000");
				jsonObj2.put("msg", "성공");
				jsonObj2.put("id", "seeminglyjs");
				jsonObj2.put("cash", "30000");

				model.addAttribute("jsonObj", jsonObj2);

			}else if(userId.equals("seeminglyjs2")) {
				JSONObject jsonObj2 = new JSONObject();

				jsonObj2.put("code", "000");
				jsonObj2.put("msg", "성공");
				jsonObj2.put("id", "seeminglyjs2");
				jsonObj2.put("cash", "35000");

				model.addAttribute("jsonObj", jsonObj2);

			}else if(userId.equals("seeminglyjs3")) {
				JSONObject jsonObj2 = new JSONObject();

				jsonObj2.put("code", "000");
				jsonObj2.put("msg", "성공");
				jsonObj2.put("id", "seeminglyjs3");
				jsonObj2.put("cash", "45000");
				model.addAttribute("jsonObj", jsonObj2);

			}else if(userId.equals("seeminglyjs4")) {
				JSONObject jsonObj2 = new JSONObject();

				jsonObj2.put("code", "000");
				jsonObj2.put("msg", "성공");
				jsonObj2.put("id", "seeminglyjs4");
				jsonObj2.put("cash", "55000");

				model.addAttribute("jsonObj", jsonObj2);
			}else {
				JSONObject jsonObj2 = new JSONObject();

				jsonObj2.put("code", "999");
				jsonObj2.put("msg", "실패");
				jsonObj2.put("id", "존재하지 않음");
				jsonObj2.put("cash", "00000");

				model.addAttribute("jsonObj", jsonObj2);
			}


		} catch (Exception e) {
			//제이슨 형변환 오류 체크
			e.printStackTrace();
		}
		return "/pintle/getPointResult";
	}

	//핀틀 포인트 차감 메소드
	@GetMapping(value= "/pintle/minusPoint")
	public void pintleMinusPoint() {

	}


	//핀틀 포인트 조회 값 처리 컨트롤러
	@SuppressWarnings("unchecked")
	@PostMapping(value ="/pintle/minusPoint")
	public String pintleMinusPointRes(HttpServletRequest request, Model model) {

		String jsonForm = request.getParameter("jsonForm");
		logger.info(jsonForm);

		//전달받은 제이슨 정보를 제이슨 객체화
		try {
			JSONParser jsonParser = new JSONParser();
			JSONObject jsonObj = (JSONObject) jsonParser.parse(jsonForm);

			String userId = (String) jsonObj.get("id");
			String payNo = (String) jsonObj.get("payNo");
			String price = (String) jsonObj.get("price");

			//userId 체크
			if(userId.equals("seeminglyjs")) {
				JSONObject jsonObj2 = new JSONObject();

				int cash = 99999999;

				cash = cash - Integer.parseInt(price);

				jsonObj2.put("code", "000");
				jsonObj2.put("msg", "성공");
				jsonObj2.put("id", "seeminglyjs");
				jsonObj2.put("paymnet", "Y");
				jsonObj2.put("payment_id", payNo);
				jsonObj2.put("payment_cash", cash);

				model.addAttribute("jsonObj", jsonObj2);

			}else if(userId.equals("seeminglyjs2")) {
				JSONObject jsonObj2 = new JSONObject();

				int cash = 99999999;

				cash = cash - Integer.parseInt(price);

				jsonObj2.put("code", "000");
				jsonObj2.put("msg", "성공");
				jsonObj2.put("id", "seeminglyjs");
				jsonObj2.put("paymnet", "Y");
				jsonObj2.put("payment_id", payNo);
				jsonObj2.put("payment_cash", cash);

				model.addAttribute("jsonObj", jsonObj2);
			}else if(userId.equals("seeminglyjs3")) {
				JSONObject jsonObj2 = new JSONObject();

				int cash = 99999999;

				cash = cash - Integer.parseInt(price);

				jsonObj2.put("code", "000");
				jsonObj2.put("msg", "성공");
				jsonObj2.put("id", "seeminglyjs");
				jsonObj2.put("paymnet", "Y");
				jsonObj2.put("payment_id", payNo);
				jsonObj2.put("payment_cash", cash);

				model.addAttribute("jsonObj", jsonObj2);

			}else if(userId.equals("seeminglyjs4")) {
				JSONObject jsonObj2 = new JSONObject();

				int cash = 99999999;

				cash = cash - Integer.parseInt(price);

				jsonObj2.put("code", "000");
				jsonObj2.put("msg", "성공");
				jsonObj2.put("id", "seeminglyjs");
				jsonObj2.put("paymnet", "Y");
				jsonObj2.put("payment_id", payNo);
				jsonObj2.put("payment_cash", cash);

				model.addAttribute("jsonObj", jsonObj2);
			}else {
				JSONObject jsonObj2 = new JSONObject();

				jsonObj2.put("code", "999");
				jsonObj2.put("msg", "실패");
				jsonObj2.put("id", "존재하지 않음");
				jsonObj2.put("paymnet", "N");
				jsonObj2.put("payment_id", "없음");
				jsonObj2.put("payment_cash", "000000");

				model.addAttribute("jsonObj", jsonObj2);
			}


		} catch (Exception e) {
			//제이슨 형변환 오류 체크
			e.printStackTrace();
		}
		return "/pintle/minusPointRes";
	}


	//핀틀 포인트 복구 form 화면
	@GetMapping(value="/pintle/recoverPoint")
	public void pintleRecoverPoint() {

	}

	//핀틀 포인트 조회 값 처리 컨트롤러
	@SuppressWarnings("unchecked")
	@PostMapping(value ="/pintle/recoverPoint")
	public String pintleRecoverPointRes(HttpServletRequest request, Model model) {

		String jsonForm = request.getParameter("jsonForm");
		logger.info(jsonForm);

		//전달받은 제이슨 정보를 제이슨 객체화
		try {
			JSONParser jsonParser = new JSONParser();
			JSONObject jsonObj = (JSONObject) jsonParser.parse(jsonForm);

			String userId = (String) jsonObj.get("id");
			String pMailId = (String) jsonObj.get("pMailId");
			String paymentId = (String) jsonObj.get("paymentId");
			String appId = (String) jsonObj.get("appId");
			String payNo = (String) jsonObj.get("payNo");
			String accessToken = (String) jsonObj.get("accessToken");

			//userId 체크
			if(userId.equals("seeminglyjs") && (payNo != null && !payNo.equals(""))) {
				JSONObject jsonObj2 = new JSONObject();

				jsonObj2.put("code", "000");
				jsonObj2.put("msg", "성공");
				jsonObj2.put("id", "seeminglyjs");
				jsonObj2.put("cancel", "성공");
				jsonObj2.put("cancel_id", "취소결과시퀀스A");

				model.addAttribute("jsonObj", jsonObj2);

			}else if(userId.equals("seeminglyjs2") && (payNo != null && !payNo.equals(""))) {
				JSONObject jsonObj2 = new JSONObject();


				jsonObj2.put("code", "000");
				jsonObj2.put("msg", "성공");
				jsonObj2.put("id", "seeminglyjs2");
				jsonObj2.put("cancel", "성공");
				jsonObj2.put("cancel_id", "취소결과시퀀스B");

				model.addAttribute("jsonObj", jsonObj2);
			}else if(userId.equals("seeminglyjs3") && (payNo != null && !payNo.equals(""))) {
				JSONObject jsonObj2 = new JSONObject();

				jsonObj2.put("code", "000");
				jsonObj2.put("msg", "성공");
				jsonObj2.put("id", "seeminglyjs3");
				jsonObj2.put("cancel", "성공");
				jsonObj2.put("cancel_id", "취소결과시퀀스C");

				model.addAttribute("jsonObj", jsonObj2);

			}else if(userId.equals("seeminglyjs4") && (payNo != null && !payNo.equals(""))) {
				JSONObject jsonObj2 = new JSONObject();

				jsonObj2.put("code", "000");
				jsonObj2.put("msg", "성공");
				jsonObj2.put("id", "seeminglyjs4");
				jsonObj2.put("cancel", "성공");
				jsonObj2.put("cancel_id", "취소결과시퀀스D");

				model.addAttribute("jsonObj", jsonObj2);
			}else {
				JSONObject jsonObj2 = new JSONObject();

				jsonObj2.put("code", "999");
				jsonObj2.put("msg", "실패");
				jsonObj2.put("id", "파라미터를 점검하세요");
				jsonObj2.put("cancel", "실패");
				jsonObj2.put("cancel_id", "취소 실패 파라미터를 점검하세요");

				model.addAttribute("jsonObj", jsonObj2);
			}

		} catch (Exception e) {
			//제이슨 형변환 오류 체크
			e.printStackTrace();
		}
		return "/pintle/recoverPointRes";
	}


	//핀틀 환불 form 화면
	@GetMapping(value="/pintle/refund")
	public void pintleRefund() {

	}

	//핀틀 환불 컨트롤러
	@PostMapping(value="/pintle/refund")
	public String printleRefundRes(HttpServletRequest request, Model model) {

		String jsonForm = request.getParameter("jsonForm");
		logger.info(jsonForm);

		JSONParser jsonParser = new JSONParser();
		JSONObject jsonObj;
		try {
			jsonObj = (JSONObject) jsonParser.parse(jsonForm);
			//알고리즘
			String alg = "AES/CBC/PKCS5Padding";

			//암호화를 위해 전달받은 파라미터(예외체크 안함)
			String aesKey = "5CJy/f6Fj1PSawUmlNWe9dXx0uzl3lUo";
			String aesIv = "pintle_test_iv01";
			//파라미터 전달 받기
			String userId = (String) jsonObj.get("id");
			String pMailId = (String) jsonObj.get("pMailId");
			String paymentId = (String) jsonObj.get("paymentId");
			String payNo = (String) jsonObj.get("payNo");
			String appId = (String) jsonObj.get("appId"); 

			//현재시간 구하기
			Date now = new Date();
			//날짜 포맷 지정
			SimpleDateFormat realNow = new SimpleDateFormat("_yyyyMMddHHmmss");
			//포맷에 따라 날짜를 문자열로 변경
			String strNow = realNow.format(now);
			logger.info("**** 현재시간 ->  " + strNow);

			//아이디에 시간을 추가하기
			//시간마다 암호화된 내용이 변경되게 하기 위해서
			userId += strNow;
			//appId및 다른 파라미터도 시간을 더한다.
			appId += strNow; 
			pMailId += strNow;
			paymentId += strNow;
			payNo += strNow;

			//리스트에 파라미터 담기
			HashMap<String, String> map= new HashMap<String, String>();
			map.put("userId", userId);
			map.put("appId",appId);
			map.put("pMailId",pMailId);
			map.put("paymentId",paymentId);
			map.put("payNo",payNo);

			//전달받은 키값과 IV 값 체크(+ 아이디값 체크)
			logger.info("**** Key ->  " + aesKey + " +  ***** IV ->  " + aesIv);
			logger.info("**** userId ->  " + userId);

			//알고리즘 aes-256
			Cipher cipher = Cipher.getInstance(alg);

			//키로 비밀키 생성
			SecretKeySpec keySpec = new SecretKeySpec(aesKey.getBytes(), "AES");
			//iv 로 spec 생성
			IvParameterSpec ivParamSpec = new IvParameterSpec(aesIv.getBytes());
			//암호화 적용
			cipher.init(Cipher.ENCRYPT_MODE, keySpec, ivParamSpec);


			//키값 가져오기
			Object [] keys = map.keySet().toArray();

			for(int i = 0; i < keys.length; i++) {

				//암호화 실행
				String temp = Base64.getEncoder().encodeToString(cipher.doFinal(map.get(keys[i]).getBytes("UTF-8")));

				//암호화한 값 재할당
				map.put((String) keys[i], temp);
			}

			//리스트 파라미터 뷰에 전달
			model.addAttribute("map", map);
			model.addAttribute("keys", keys);
			model.addAttribute("keySize", keys.length -1);
		}catch (Exception e) {
			logger.info("암호화 중 오류 발생 ");
			e.printStackTrace();
		}
		return "/pintle/refundRes";	
	}

	//암호 해독하는 컨트롤러
	@PostMapping(value="/pintle/refundCheck")
	public String refundCheck(HttpServletRequest request, Model model) {
		String alg = "AES/CBC/PKCS5Padding";

		//암호화를 위해 전달받은 파라미터(예외체크 안함)
		String aesKey = "5CJy/f6Fj1PSawUmlNWe9dXx0uzl3lUo";
		String aesIv = "pintle_test_iv01";
		//파라미터 전달 받기
		String userId = request.getParameter("userId");
		String pMailId = request.getParameter("pMailId");
		String paymentId = request.getParameter("paymentId");
		String payNo = request.getParameter("payNo");
		String appId = request.getParameter("appId"); 

		//map에 정보 저장
		HashMap<String, String> map = new HashMap<String, String>();
		map.put("userId", userId);
		map.put("appId",appId);
		map.put("pMailId",pMailId);
		map.put("paymentId",paymentId);
		map.put("payNo",payNo);
		
		Object [] keys = map.keySet().toArray(); // 키 저장
		List<String> times = new ArrayList<String>(); //시간을 담을 리스트
		
		
		//----암호화 해석 코드
		//알고리즘 선택
		try {
			Cipher cipher = Cipher.getInstance(alg);

			SecretKeySpec keySpec = new SecretKeySpec(aesKey.getBytes(), "AES");
			IvParameterSpec ivParamSpec = new IvParameterSpec(aesIv.getBytes());
			cipher.init(Cipher.DECRYPT_MODE, keySpec, ivParamSpec);
			
			for(int i =0; i < keys.length; i++) {
				//암호 해석
				byte[] decodedBytes = Base64.getDecoder().decode(map.get(keys[i]));
				byte[] decrypted = cipher.doFinal(decodedBytes);
				String result = new String(decrypted);
				
				//시간과 실제 정보 나누기
				String [] temp = result.split("_");
				
				//시간 정보를 담는다.
				times.add(temp[1]);
				
				// 암호 해석 후 재할당
				map.put((String)keys[i], temp[0]);
				logger.info((String)keys[i] + " -->  " +map.get(keys[i]));
			}
			
			Date date = new Date();
			SimpleDateFormat sf = new SimpleDateFormat("yyyyMMddHHmmss");
			String now = sf.format(date);
			
			//현재날짜 시간 구하기
			Double checkNow = Double.valueOf(now);
			
			for(int i = 0; i < times.size(); i++) {
				if(Double.valueOf(times.get(i)) + 1800 < checkNow) {
					//암호화 시간에서 30분 더한시간보다 현재 시간이 더 크면 만료된 암호
					logger.info("암호 발급 시간[암호만료됨] - > " + times.get(i));
					break;
				}else {
					logger.info("암호 발급 시간 - > " + times.get(i));
				}
			}
			
			
		}catch (Exception e) {
			e.printStackTrace();
		}
		model.addAttribute("keys", keys);
		model.addAttribute("keySize", keys.length -1);
		model.addAttribute("map", map);
		return "/pintle/forwardRefundInfo";
	}

}
