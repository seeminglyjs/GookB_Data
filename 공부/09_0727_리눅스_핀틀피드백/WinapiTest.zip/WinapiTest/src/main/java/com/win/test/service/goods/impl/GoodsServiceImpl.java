package com.win.test.service.goods.impl;

import java.util.List;

import org.springframework.stereotype.Service;

import com.win.test.service.goods.face.GoodsService;

@Service
public class GoodsServiceImpl implements GoodsService {

	@Override
	public List<String> getGoodsList(String mdcode) {
		
		return null;
	}
}
