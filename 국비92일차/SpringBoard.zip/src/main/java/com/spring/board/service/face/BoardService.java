package com.spring.board.service.face;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.spring.board.dto.Board;
import com.spring.board.util.Paging;

public interface BoardService {

	/**
	 * 게시글의 페이징을 가져올 메소드
	 * 
	 * @param request
	 * @return
	 */
	public Paging getPaging(HttpServletRequest request);

	/**
	 * 페이징을 매개값으로 받아 게시글을 보여줄 메소드
	 * 
	 * @param paging
	 * @return
	 */
	public List<Board> getList(Paging paging);

}
