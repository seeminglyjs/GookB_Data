package com.spring.board.service.impl;

import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.board.dao.face.MemberDao;
import com.spring.board.dto.Member;
import com.spring.board.service.face.MemberService;

@Service
public class MemberServiceImpl implements MemberService{

	
	@Autowired
	MemberDao memberDao;
	
	@Override
	public Member getUser(HttpServletRequest request) {
		
		Member member = new Member();
		
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		
		HashMap<String, String> map = new HashMap<String, String>();
		
		map.put("id", id);
		map.put("pw", pw);
		
		member = memberDao.selectUserByLogin(map);
		
		return member;
	}
	
	
	
	@Override// 아이디 중복성 체크 메소드
	public Member overlapUser(HttpServletRequest request) {
		
		String id = request.getParameter("id");
		
		Member member = memberDao.selectUserById(id);
		
		return member;
	}
	
	
	@Override // 신규 유저를 저장하는 메소드
	public void joinUser(HttpServletRequest request) {
		
		String id = request.getParameter("id");
		String pw = request.getParameter("pw");
		String nick = request.getParameter("pw");
		
		HashMap<String, String> map = new HashMap<String, String>();
		
		map.put("id", id);
		map.put("pw", pw);
		map.put("nick", nick);
		
		memberDao.insertUser(map);

	}
}
