package com.spring.board.dao.face;

import java.util.List;

import com.spring.board.dto.Board;
import com.spring.board.util.Paging;

public interface BoardDao {

	/**
	 * 전체 게시글 수를 세는 메소드
	 * 
	 * @return
	 */
	public int selectCntAll();

	/**
	 * 요청 파라미터에 따른 전체 게시글을 가져오는 메소드
	 * 
	 * @param paging
	 * @return
	 */
	public List<Board> selectAll(Paging paging);

}
