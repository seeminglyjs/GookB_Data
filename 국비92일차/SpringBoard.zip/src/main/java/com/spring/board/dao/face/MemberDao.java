package com.spring.board.dao.face;

import java.util.HashMap;

import com.spring.board.dto.Member;

public interface MemberDao {

	// 로그인 정보가 맞는지 조회하는 메소드
	public Member selectUserByLogin(HashMap<String, String> map);

	// id로 유저를 조회하는 메소드
	public Member selectUserById(String id);

	// 신규 유저 를 저장하는 메소드
	public void insertUser(HashMap<String, String> map);

}
