package com.spring.board.service.face;

import javax.servlet.http.HttpServletRequest;

import com.spring.board.dto.Member;

public interface MemberService {

	// 로그인한 유저 정보를 체크하는 메소드
	public Member getUser(HttpServletRequest request);

	//회원가입 유저 아이디 중복성 체크
	public Member overlapUser(HttpServletRequest request);

	// 유저 회원가입 메소드
	public void joinUser(HttpServletRequest request);

}
