package com.spring.board.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.spring.board.dao.face.BoardDao;
import com.spring.board.dto.Board;
import com.spring.board.service.face.BoardService;
import com.spring.board.util.Paging;

@Service
public class BoardServiceImpl implements BoardService{

	@Autowired
	BoardDao boardDao;
	
	@Override // 페이징을 구하는 메소드
	public Paging getPaging(HttpServletRequest request) {
		//전달파라미터 curPage 파싱
		String param = request.getParameter("curPage");
		int curPage = 0; // 기본값 설정
		if(param != null && !"".equals(param)) {
			curPage = Integer.parseInt(param);
		}
		
		//Board 테이블의 총 게시글 수를 조회한다
		int totalCount = boardDao.selectCntAll();

		//Paging객체 생성
		Paging paging = new Paging(totalCount, curPage);
		
		return paging;
	}
	
	
	@Override // 전체 게시글을 보여주는 메소드
	public List<Board> getList(Paging paging) {
	
		List<Board> list = new ArrayList<Board>();
		
		list = boardDao.selectAll(paging);
		
		return list;
	}
	
}
