package com.spring.board.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.spring.board.dto.Member;
import com.spring.board.service.face.MemberService;

@Controller
public class MemberController {

	@Autowired
	MemberService memberService;
	
	@RequestMapping(value = "/member/login")
	public void login() {
		
	}
	
	// 유저의 로그인 정보를 체크
	@RequestMapping(value = "/member/login", method = RequestMethod.POST)
	public String loginRes(HttpServletRequest request, HttpSession session) {
		
		Member member = memberService.getUser(request);
		
		// 미가입 유저 및 잘못된 정보 입력시 다시 로그인 페이지 이동
		if(member == null || member.getId() == null || member.getId().equals("")) {
			return "redirect:/member/login";
		}else {
			// 가입 유저 세션 할당
			session.setAttribute("login", true);
			session.setAttribute("member", member);
			return "redirect:/";
		}	
	}
	// 로그아웃
	@RequestMapping(value = "/member/logout")
	public String logout(HttpSession session) {
		session.invalidate();
		return "redirect:/";
	}

	//회원 가입 폼
	@RequestMapping(value = "/member/join")
	public void join(HttpSession session) {
	
	}
	
	//회원 가입 폼
	@RequestMapping(value = "/member/join", method = RequestMethod.POST)
	public String joinRes(HttpServletRequest request, HttpSession session) {
		Member member = memberService.overlapUser(request);
		
		if(member != null) {
			// 이미 존재하는 유저
			return "redirect:/member/join";
		}else {
			//미가입 유저
			memberService.joinUser(request);
			return "redirect:/";
		}	
	}


}
