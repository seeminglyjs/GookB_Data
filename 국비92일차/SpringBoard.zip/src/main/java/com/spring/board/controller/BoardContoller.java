package com.spring.board.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.spring.board.dto.Board;
import com.spring.board.service.face.BoardService;
import com.spring.board.util.Paging;

@Controller
@RequestMapping(value = "/board")
public class BoardContoller {

	@Autowired
	BoardService boardService;
	
	private static final Logger logger = LoggerFactory.getLogger(BoardContoller.class); 
	
	@RequestMapping(value = "/list")
	public void list(HttpServletRequest request, Model model) {
		
		// 페이징을 얻어온다.
		Paging paging = boardService.getPaging(request);
		
		List<Board> list = new ArrayList<Board>();
		
		// 페이지의 해당 하는 게시글 목록을 얻어온다.
		list = boardService.getList(paging);
		
		//페이징/ 게시글과 게시글갯수를 넘긴다.
		model.addAttribute("paging", paging);
		model.addAttribute("list", list);		
		model.addAttribute("listSize", list.size());
		
	}
}
