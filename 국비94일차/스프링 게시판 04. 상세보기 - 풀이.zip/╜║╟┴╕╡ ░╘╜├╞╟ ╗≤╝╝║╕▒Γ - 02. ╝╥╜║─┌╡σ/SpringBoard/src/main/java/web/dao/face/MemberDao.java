package web.dao.face;

import web.dto.Member;

public interface MemberDao {

	public void join(Member member);
	
	public int selectByUserid(Member member);
	
	public int login(Member member);
	
	public String getUsernick(Member member);
	
}
