package web.controller;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import web.dto.Member;
import web.service.face.MemberService;

@Controller
@RequestMapping(value="/member")
public class MemberController {

	private static final Logger logger = LoggerFactory.getLogger(MemberController.class);

	@Autowired private MemberService memberService;

	@RequestMapping(value="/main")
	public void main() { }

	@RequestMapping(value="/join", method=RequestMethod.GET)
	public void join() { }

	@RequestMapping(value="/join", method=RequestMethod.POST)
	public String joinProcess(Member member) {
		boolean joinResult = memberService.join(member);

		if(joinResult) {
			logger.info("회원가입 성공");
			return "redirect:/";

		} else {
			logger.info("회원가입 실패");
			return "redirect:/member/join";

		}

	}

	@RequestMapping(value="/login", method=RequestMethod.GET)
	public void login() { }

	@RequestMapping(value="/login", method=RequestMethod.POST)
	public String loginProcess(
			Member member,
			HttpSession session) {

		boolean loginResult = memberService.login(member);

		if(loginResult) {
			logger.info("로그인 성공");

			session.setAttribute("login", true);
			session.setAttribute("id", member.getId());
			session.setAttribute("nick", memberService.getUsernick(member));

			logger.debug("세션상태 : " + session.getAttribute("login"));
			logger.debug("세션 아이디 : " + session.getAttribute("id"));
			logger.debug("세션 닉네임 : " + session.getAttribute("nick"));

			return "redirect:/";

		} else {
			logger.info("로그인실패");
			return "redirect:/member/login";
		}

	}

	@RequestMapping(value="/logout")
	public String logout(HttpSession session) {

		session.invalidate();

		return "redirect:/";
	}

}
