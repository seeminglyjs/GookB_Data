package web.service.face;

import web.dto.Member;

public interface MemberService {

	/**
	 * 신규 회원 가입 처리
	 * 
	 * @param member - 신규 회원 정보 객체
	 * @return 회원가입 처리  결과
	 */
	public boolean join(Member member);

	/**
	 * 로그인 처리
	 * 
	 * @param member - id와 pw를 가진 객체
	 * @return 로그인 처리 결과
	 */
	public boolean login(Member member);

	/**
	 * 사용자의 닉네임 조회
	 * 
	 * @param member - 조회할 회원번호를 가진 객체
	 * @return 조회된 닉네임
	 */
	public String getUsernick(Member member);
	
}
