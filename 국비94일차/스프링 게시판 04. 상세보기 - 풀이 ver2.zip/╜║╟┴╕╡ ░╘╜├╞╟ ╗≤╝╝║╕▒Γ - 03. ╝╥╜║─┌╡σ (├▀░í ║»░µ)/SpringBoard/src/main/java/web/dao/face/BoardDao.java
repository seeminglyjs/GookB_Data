package web.dao.face;

import java.util.List;

import web.dto.Board;
import web.util.Paging;

public interface BoardDao {

	/**
	 * 전체 게시글 수를 조회한다
	 * 
	 * @return 총 게시글 수
	 */
	public int selectCntAll();
	
	/**
	 * 페이징을 적용하여 게시글 목록 조회
	 * 	Paging.startNo, Paging.endNo를 활용한다
	 * 	board_no가 아닌 rownum을 이용하여 조회한다
	 * 
	 * @param paging - 페이징 정보 객체
	 * @return 페이징이 적용된 게시글 목록
	 */
	public List<Board> selectPageList(Paging paging);
	
	/**
	 * 조회하려는 게시글의 조회수를 1 증가시킴
	 * 
	 * @param viewBoard - 게시글번호를 가진 객체
	 */
	public void updateHit(Board viewBoard);
	
	/**
	 * 게시글번호를 이용하여 게시글을 조회한다
	 * 
	 * @param viewBoard - 게시글번호를 가진 객체
	 * @return 조회된 게시글
	 */
	public Board selectBoardByBoardNo(Board viewBoard);

}
