package web.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import web.dto.Dept;
import web.service.HelloService;

@Controller // 컨트롤러 컴포넌트 빈으로 등록한다
public class HelloController {
	
	// 로그 객체
	private static final Logger logger = LoggerFactory.getLogger(HelloController.class);
	
	//서비스 객체
	@Autowired // 알아서 impl 클래스를 찾아서 의존성을 주입한다
	private HelloService helloService; 
	
	@RequestMapping(value = "/hi", method=RequestMethod.GET)
	public void hi() { // /hi라는 url에 접속하면 메소드가 실행됨
		System.out.println("/hi [get]");
	}
	
	@RequestMapping(value = "/hello1", method=RequestMethod.GET)
	public String hello(String param, Model model) { // req.getParameter("param") 이랑 동일함
		logger.info("/hello1 [Get]");
		
//		logger.info("변수 출력하기 : { }", 1000);
		logger.info("param -> {}", param);
		
//		logger.error("에러 로그!");
//		logger.debug("디버그 로그!");
//		logger.warn("원 로그!");
//		logger.trace("트레이스 로그!");
		
		//------------------------------------------------		
		
		List<Dept> list = helloService.ServiceTest();
		
		//view에 전달값 전달하기
		model.addAttribute("list", list);
		
		//viewName 지정하기
		return "test/hello";
	}
}
