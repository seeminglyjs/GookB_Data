package login.dao;

import java.util.HashMap;

import login.dto.Login;

public interface LoginDao {

	/**
	 * 유저 정보를 삽입하는 쿼리 DAO
	 * 
	 * @param map
	 */
	public void InsertUser(HashMap<String, String> map);

	/**
	 * 유저 정보를 찾아오는 쿼리 DAO
	 * 
	 * @param map
	 * @return
	 */
	public Login selectUser(HashMap<String, String> map);

	/**
	 * 로그인 아이디 패스워드가 일치하는 행의 수
	 * 
	 * @param login
	 * @return
	 */
//	public int selectCnt(Login login);

}
