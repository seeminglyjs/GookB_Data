package di.xml;

import di.tire.Tire;

public class Car {

	private Tire tire;
	
	public String getInfo() {
		return tire.getProduct() + " - -장착";
	}
	
	public void setTire(Tire tire) {
		this.tire = tire;
	}

	public Tire getTire() {
		return tire;
	}
}
