package login.controller;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import login.dto.Login;
import login.service.face.LoginService;

@Controller
public class LoginController {

	private static final Logger logger = LoggerFactory.getLogger(LoginController.class); 

	@Autowired LoginService loginService;
	
	
	@RequestMapping(value="/login/main")
	public void main() { }
	
	
	@RequestMapping(value="/login/join", method=RequestMethod.GET)
	public void join() { }

	@RequestMapping(value="/login/join", method=RequestMethod.POST)
	public String joinProc( Login login ) {
		logger.info("/login/join [POST]");
		logger.info("전달 파라미터 : {}", login);
		
		//회원가입 처리
		loginService.join(login);
		
		//메인페이지 리다이렉션
		return "redirect:/login/main";
		
	}

	
	@RequestMapping(value="/login/login", method=RequestMethod.GET)
	public void login() { }
	
	@RequestMapping(value="/login/login", method=RequestMethod.POST)
	public String loginProc( Login login, HttpSession session ) {
		logger.info("/login/login [POST] : {}", login);
		
		//아이디, 패스워드 DB 조회 - 인증
		boolean isLogin = loginService.login(login); //true - 인증 성공
		
		//인증 결과에 따른 세션 처리
		if( isLogin ) {
			session.setAttribute("login", isLogin);
			session.setAttribute("loginid", login.getId());
		}
	
		return "redirect:/login/main";
	}

	
	@RequestMapping("/login/mypage")
	public void mypage() { }
	
	
	@RequestMapping("/login/logout")
	public String logout(HttpSession session) {
		
		//세션 해제
		session.invalidate();
		
		return "redirect:/login/main";
		
	}
	
}













