package login.dao.face;

import login.dto.Login;

public interface LoginDao {

	/**
	 * 신규 회원가입정보를 삽입한다
	 * 
	 * @param login - 신규 회원가입 정보
	 */
	public void insert(Login login);
	
	/**
	 * 로그인 아이디,패스워드가 일치하는 행(사용자)의 수 구하기
	 * 
	 * @param login - 로그인 아이디,패스워드 정보
	 * @return 일치하는 행(사용자) 수
	 */
	public int selectCnt(Login login);
	
}



