package login.service.face;

import login.dto.Login;

public interface LoginService {

	/**
	 * 신규 회원 가입
	 * 
	 * @param login - 회원가입될 사용자의 정보
	 */
	public void join(Login login);
	
	/**
	 * 로그인 인증 처리
	 * 	ID&PW 를 이용하여 행 COUNT를 조회한다
	 *  존재하면 인증 성공 true 반환
	 *  존재하지 않으면 인증 실패 false 반환
	 * 
	 * @param login - 로그인 아이디,패스워드 정보 객체
	 * @return
	 * 		true	- 로그인 인증 성공
	 * 		false	- 로그인 인증 실패
	 */
	public boolean login(Login login);
	
}




