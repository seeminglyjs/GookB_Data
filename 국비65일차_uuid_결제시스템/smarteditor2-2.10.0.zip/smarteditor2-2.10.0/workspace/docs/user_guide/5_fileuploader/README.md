# 부록. jindo.FileUploader {#jindo-fileuploader}

이 장에서는 사진 퀵 업로더에서 사용하는 jindo.FileUploader에 대해서 설명한다.