package web.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;

import web.dto.Board;
import web.dto.Boardfile;
import web.service.face.BoardService;
import web.util.Paging;

@Controller
@RequestMapping(value="/board")
public class BoardController {

	private static final Logger logger = LoggerFactory.getLogger(BoardController.class);
	
	@Autowired private BoardService boardService;
	
	
	@RequestMapping(value="/list")
	public void list( Paging inData, Model model ) {
		logger.info("/board/list [GET]");
		
		//페이징 계산
		Paging paging = boardService.getPaging( inData );
		logger.debug(paging.toString());
		
		//게시글 목록 조회
		List<Board> list = boardService.list( paging );
		for( int i=0; i<list.size(); i++ ) {
			logger.debug( list.get(i).toString() );
		}

		//모델값전달
		model.addAttribute("list", list);
		model.addAttribute("paging", paging);
	}
	
	@RequestMapping(value = "/error")
	public void error() { }
	
	@RequestMapping(value="/view")
	public String view(Board viewBoard, Model model) {
		logger.debug("boardno : {}", viewBoard.toString());
	
		// 게시글 번호가 1보다 작으면 목록으로 보내기
		if(viewBoard.getBoardNo() < 1) {
			return "redirect:/board/list";
		}
		
		// 게시글 상세 정보 전달
		viewBoard = boardService.view(viewBoard);
		logger.debug("상세보기 : {}", viewBoard.toString());
		model.addAttribute("view", viewBoard);
		
		//게시글 첨부파일 전달
		Boardfile boardfile = boardService.getAttachFile(viewBoard);
		model.addAttribute("boardfile", boardfile);
		
		return "board/view";
	}
	
	@RequestMapping(value = "/write", method = RequestMethod.GET)
	public void write() { }
	
	@RequestMapping(value = "/write", method = RequestMethod.POST)
	public String writeProc(Board board, MultipartFile file, HttpSession session) {
		logger.debug("글쓰기 : {}", file);
		
		//작성자 ID, NICK 추가 - 세션
		board.setWriterId((String) session.getAttribute("id"));
		board.setWriterNick((String) session.getAttribute("nick"));
		
		logger.debug("글쓰기 : {}", board);
		
		boardService.write(board, file);
		
		return "redirect:/board/list";
	}
	
	@RequestMapping(value="/download")
	public String download(int fileNo, Model model) {
		
		Boardfile file = boardService.getFile(fileNo);
		logger.debug("조회된 파일 {}", file);
		
		//다운로드할 파일의 정보를 모델값으로 뷰에 전달
		model.addAttribute("downFile", file);
		
		//viewName 지정하기
		return "down";
	}
	
	@RequestMapping(value="/update", method=RequestMethod.GET)
	public String update(Board board, Model model) {
		logger.debug("boardno : {}", board.toString());
		
		// 게시글 번호가 1보다 작으면 목록으로 보내기
		if(board.getBoardNo() < 1) {
			return "redirect:/board/list";
		}
		
		// 게시글 상세 정보 전달
		board = boardService.view(board);
		logger.debug("상세보기 : {}", board.toString());
		model.addAttribute("view", board);
		
		//게시글 첨부파일 전달
		Boardfile boardfile = boardService.getAttachFile(board);
		model.addAttribute("boardfile", boardfile);
		
		return "board/update";
	}

	@RequestMapping(value="/update", method=RequestMethod.POST)
	public String updateProcess(Board board, MultipartFile file, HttpSession session) {
		logger.debug("글수정 : {}", file);
		
		//작성자 ID, NICK 추가 - 세션
		board.setWriterId((String) session.getAttribute("id"));
		board.setWriterNick((String) session.getAttribute("nick"));
		
		logger.debug("글수정 : {}", board);
		
		boardService.update(board, file);
		
		return "redirect:/board/view?boardNo="+board.getBoardNo();
	}
	
	@RequestMapping(value="/delete", method=RequestMethod.GET)
	public String deleteProcess(Board board) {
		boardService.delete(board);
		
		return "redirect:/board/list";
	}
	
}







