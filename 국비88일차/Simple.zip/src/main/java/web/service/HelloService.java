package web.service;

import java.util.List;

import web.dto.Dept;

public interface HelloService {

	public List<Dept> ServiceTest();
}
