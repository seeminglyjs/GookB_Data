package web.controller;

import java.util.HashMap;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import web.dto.User;

@Controller
public class ParamController {

	// 로그 객체
	private static final Logger logger = LoggerFactory.getLogger(ParamController.class);
	
	@RequestMapping(value="/param/requestParam", method=RequestMethod.GET)
	public String paramForm() {
		logger.info("/param/requestParam [GET] 요청 성공");	
		//VIEW 지정
		return "param/paramForm";
	}
	
	
	@RequestMapping(value="/param/requestParam", method=RequestMethod.POST)
	public String paramResult(@RequestParam(required = true) String name, int age, Model model) {
		logger.info("/param/requestParam [POST] 요청 성공");	

		logger.info(name);
		logger.info("{}",age);
		logger.info("" + age);
		
		//요청 파라미터 view에 전달
		model.addAttribute("name", name);
		model.addAttribute("age", age);
		
		//VIEW 지정
		return "param/paramResult";
	}
	
	
	@RequestMapping(value = "/param/required") // value는 생략이 가능하다
	public void requiredTest(@RequestParam(required = true) String test) {
		
		logger.info("/param/required -{}", test);
	}
	
	@RequestMapping(value = "/param/mapForm", method=RequestMethod.GET)
	public void paramMapForm() {
		
		logger.info("/param/mapForm get 요청");
	}
	
	
	@RequestMapping(value="/param/mapResult", method=RequestMethod.POST)
	public void paramMapResult(@RequestParam HashMap<String, String> map
			, Model model) {
		logger.info("/param/mapForm post 요청");
		logger.info(map.toString());
	
		// 맵 객체 자체를 모델값으로 전달한다
		model.addAttribute("map", map);
		
		// 맵객체 내부의 키=값 쌍을 각각의 모델값으로 분리해서 전달한다
		model.addAllAttributes(map);
	}
	
	@RequestMapping(value="/param/dto", method=RequestMethod.GET)
	public void paramDtoForm() {
		logger.info("/param/dto [GET]");
		
	}
	
	@RequestMapping(value="/param/dto", method=RequestMethod.POST)
	public String paramDto(User user
			,@ModelAttribute("userData") User user2 // 커맨드 객체
			) { // 변수명만 맞추주면 DTO에 알아서 들어간다
		// 커맨드 객체는 앞에 @ModelAttribute 어노테이션이 생략되어 있다.
		//ex)  @ModelAttribute User user 때문에 따로 모델지정 안해줘도
		// JSP에서 받을 수 있다 ${user } 이런식으로 사용가능
		
		logger.info("/param/dto [post]");
		logger.info(user.toString());
		
		//-------------------------
		user2.setName("bbb");
		user2.setAge(15); // 나중에 변경하면 파라미터로 받은값이 아니라
		// 나중에 변경된 값으로 들어가게 된다.
		
		user2 = new User();
		user2.setName("ccc");
		user2.setAge(25); 
		// 새로운 객체는 아예 다른 객체이기 때문에 jsp 보낼려면
		// Model 객체로 addAttribute 해주어야 한다.
		
		return "param/dtoResult";
	}
	
	@RequestMapping(value="/param/test")
	public void paramTest1(Model model) {
		//viewName : param/test
		//view : /WEB-INF/views/param/test.jsp
		
		model.addAttribute("data","MODEL DATA");
	}
	
	
	@RequestMapping(value="/param/test2")
	public String paramTest2(Model model) {

		//return null; // void리턴타입과 같은 동작
		//return ""; // views/.jsp 를 찾음
	
		model.addAttribute("data","MODEL DATA2");
		
		return "param/test";
	}
	
	
	@RequestMapping(value="/param/test3")
	public ModelAndView paramTest3(ModelAndView mav) {

		//ModelAndView mav = new ModelAndView();
		
		mav.addObject("data", "Model data 3"); // 모델값 지정
		mav.setViewName("param/test"); // viewName 지정
//		mav.setViewName(null); // void 리턴타입과 동일한 동작
		
		return mav;
	}
}
