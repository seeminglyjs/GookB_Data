package web.service.face;

import web.dto.Member;

public interface MemberService {

	/**
	 * 신규 회원 가입
	 * 
	 * @param member - 신규 회원 정보 객체
	 * @return 회원가입 결과
	 */
	public boolean join(Member member);

	public boolean login(Member member);

	public String getUsernick(Member member);
	
}
